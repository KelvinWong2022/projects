<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Navigation;
use App\Models\Language;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Article;
use Illuminate\Support\Facades\URL;
use Session;
class IndexController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
       // echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
           session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');
        
        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;

        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------
        $articlesObject = new Article();
        $home_sections=$articlesObject->GetArticleList(1001,1,$language);
        $data['home_sections']= $home_sections;

        $data['home_news']=$articlesObject->GetArticleList(1001,3,$language);

        return view('index')->with('page_data',$data);
    }
    public function index_bk()
    {
// echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
            session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');

        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;
        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------
        $articlesObject = new Article();
        $home_sections=$articlesObject->GetArticleList(1001,1,$language);

        $data['home_sections']= $home_sections;

        return view('index_bk')->with('page_data',$data);
    }
    public function page($id)
    {
        // echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
            session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');

        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;
        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------
        $articlesObject = new Article();
        $page_article=$articlesObject->GetArticleByIdLg($id,$language);
        $data['page_article']=$page_article[0];
        return view('page')->with('page_data',$data);
    }
     public function changelanguage($lg)
    {
          session(['weblanguage' =>$lg]);

         //echo Session::get('weblanguage');
        
         //$previous_url = $this->session->userdata('previous_url');
       // $this->session->set_userdata('edulanguage', $lg);
        //echo $previous_url;
       // redirect($previous_url, 'refresh');
        header('Location: '.url()->previous());
       
    }

    public function client_reg_save(Request $request)
    {
        $first_name = $request->input('first_name');
        $last_name = $request->input('last_name');
        $email = $request->input('email');
        $mobile_number= $request->input('mobile_number');
        $country = $request->input('country');


        $counselling = $request->input('counselling');
        $policy = $request->input('policy');
        $phone = $request->input('phone');
        $info = $request->input('info');

        $articlesObject = new Article();
        $result=$articlesObject->client_add($first_name,$last_name,$email,$mobile_number,$country,$counselling,$policy,$phone,$info);

        return response()->json($UserAdminUser=array("data"=>$result));
    }
    public function index_appointment(Request $request)
    {
        $first_name = $request->input('tb_first_name');
        $last_name = $request->input('tb_last_name');
        $email = $request->input('tb_email');
        $mobile_number= $request->input('tb_mobile_number');
        $country = $request->input('slt_country');

        $counselling = $request->input('slt_counselling');

        $ck_policy = $request->input('ck_policy');
        $ck_phone = $request->input('ck_phone');
        $ck_info = $request->input('ck_info');

        if($ck_policy=="on"){
            $ck_policy="Yes";
        }else{
            $ck_policy="No";
        }
        if($ck_phone=="on"){
            $ck_phone="Yes";
        }else{
            $ck_phone="No";
        }
        if($ck_info=="on"){
            $ck_info="Yes";
        }else{
            $ck_info="No";
        }


        $articlesObject = new Article();
        $articlesObject->client_add($first_name,$last_name,$email,$mobile_number,$country,$counselling,$ck_policy,$ck_phone,$ck_info);
        session(['appointment_msg' =>'yes']);
        header('Location: /index.php/contact');
    }
    public function overseas_studies()
    {
        // echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
            session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');

        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;
        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------
        $articlesObject = new Article();
        $page_article=$articlesObject->GetArticleByIdLg(21,$language);
        $data['page_article']=$page_article[0];
        return view('overseas')->with('page_data',$data);
    }
    public function index_ossd()
    {
        // echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
            session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');

        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;
        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------
        $articlesObject = new Article();
        $page_article=$articlesObject->GetArticleByIdLg(11,$language);
        $data['page_article']=$page_article[0];
        return view('ossd')->with('page_data',$data);
    }

    public function index_contact()
    {
        // echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
            session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');

        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;
        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------

        if(session('appointment_msg')==null){
            $language='en';
            session(['appointment_msg' =>'no']);
        }
        $data['appointment_msg']=session('appointment_msg');
        session(['appointment_msg' =>'no']);
        $articlesObject = new Article();
        $page_article=$articlesObject->GetArticleByIdLg(17,$language);
        $data['page_article']=$page_article[0];
        return view('contact')->with('page_data',$data);
    }

    public function index_newslist()
    {
        // echo config('app.name');
        if(session('weblanguage')==null){
            $language='en';
            session(['weblanguage' =>'en']);

        }
        else{
            $language=session('weblanguage');
        }
        //echo session('weblanguage');

        //header---------------------------------------------------------------------------------------
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetNav($page_menu->nav_id,$language);
        }
        $data=array();
        $data['main_menus']=$page_menus;
        $my_Language=new Language();
        $data['appointment_text']=$my_Language->header_section($language);
        //header---------------------------------------------------------------------------------------
        $articlesObject = new Article();
        $data['home_news']=$articlesObject->GetArticleList(1001,3,$language);
        $page_article=$articlesObject->GetArticleByIdLg(22,$language);
        $data['page_article']=$page_article[0];

        return view('news_list')->with('page_data',$data);
    }
    public function index_myvalidate()
    {
        $data['msg']="";
        return view('validation')->with('page_data',$data);
    }

    public function index_myvalidate_post(Request $request)
    {
        $data['msg']="";
        $validated = $request->validate([
            'title' => 'required|email:rfc,dns'
            //'body' => 'required',
        ]);
        return view('validation')->with('page_data',$data);
    }
}
