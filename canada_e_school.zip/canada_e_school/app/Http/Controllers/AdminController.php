<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Article;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Navigation;
use App\Models\User;
use App\Imports\UsersImport;
use Maatwebsite\Excel\Facades\Excel;
class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    //https://canadaeschool.mysmartedu.com/index.php/smartadmin
    public function index()
    {
       $data['admin_name']= config('constants.ADMIN_NAME');
        return view('production/login')->with('page_data',$data);;
        
    }

    public function menu_page_list($category)
    {

      if(session('webpage_msg')==null){
         redirect('/smartadmin/'.$category);
      }
      else{
          if(session('webpage_msg') !="authenticate20210125"){
              redirect('/smartadmin/'.$category);
          }
      }
        $language='en';
        $postType=1001;
       
        if ($category==2) {
            $data['page_title']="Pages of Menu";
        }
        elseif($category==3) {
            $data['page_title']="News";
        }
        else {
            $data['page_title']="Sections of home page";
        }
        //$category=1;

        $Navigations = new Navigation();
        $page_menus=$Navigations->GetAdminNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetAdminNav($page_menu->nav_id,$language);
        }

        $data['page_menus']=$this->genLeftMenu($page_menus);

        $articlesObject = new Article();
        $articles=$articlesObject->GetArticleList($postType,$category,$language);
        $data['articles']= $articles;
        $data['admin_name']= config('constants.ADMIN_NAME');
        return view('production/menu_page_list')->with('page_data',$data);
        
    }
    public function menu_page_add($cid)
    {
        $language='en';


        if(session('webpage_msg')==null){
            $data['msg']="";
            session(['webpage_msg' =>'']);

        }
        else{
            $data['msg']=session('webpage_msg');
        }

        $data['category']=$cid;
        $Navigations = new Navigation();
        $page_menus=$Navigations->GetAdminNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetAdminNav($page_menu->nav_id,$language);
        }

        $data['page_menus']=$this->genLeftMenu($page_menus);

        $data['admin_name']= config('constants.ADMIN_NAME');
        return view('production/menu_page_add')->with('page_data',$data);;

    }
    public function menu_page_mod($id)
    {
        $language='en';
        $articlesObject = new Article();
        $articles=$articlesObject->GetArticleById($id);
        $data['article']= $articles[0];

        if(session('webpage_msg')==null){
             $data['msg']="";
           session(['webpage_msg' =>'']);

        }
        else{
            $data['msg']=session('webpage_msg');
        }


        $Navigations = new Navigation();
        $page_menus=$Navigations->GetAdminNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetAdminNav($page_menu->nav_id,$language);
        }

        $data['page_menus']=$this->genLeftMenu($page_menus);

        $data['admin_name']= config('constants.ADMIN_NAME');
        return view('production/menu_page_detail')->with('page_data',$data);;

    }

    public function menu_page_add_save(Request $request)
    {
        //upload image
        $imageName="";
        if ($request->hasFile('image')){
            $imageName = time().'.'.$request->image->extension();

            $request->image->move(public_path('images'), $imageName);
            // $request->image->storeAs('images', $imageName);
        }

        if($imageName==""){
            $imageName="aa.jpg";
        }
        //upload image

        $title_en = $request->input('title_en');
        $title_tc = $request->input('title_tc');
        $title_sc = $request->input('title_sc');
        $category= $request->input('category');
        $img = $imageName;
        $text_en = $request->input('text_en');
        $text_tc = $request->input('text_tc');
        $text_sc = $request->input('text_sc');
        $sortid = $request->input('sortid');
        $articlesObject = new Article();
        $result=$articlesObject->AddArticle($title_en,$title_tc,$title_sc,$img,$category,$text_en,$text_tc,$text_sc,$sortid);
        return redirect('/menu_list/'.$category);
        // session(['webpage_msg' =>'Update completed']);
        //return redirect('/menu_mod/'.$id);
    }
    public function menu_page_mod_save(Request $request)
    {
        $id = $request->input('articleid');
        //upload image
        $imageName=$request->input('hd_image');
         if ($request->hasFile('image')){
            $imageName = time().'.'.$request->image->extension();

        $request->image->move(public_path('images'), $imageName);
           // $request->image->storeAs('images', $imageName);
         }

         if($imageName==""){
             $imageName="aa.jpg";
         }
        //upload image

        $title_en = $request->input('title_en');
        $title_tc = $request->input('title_tc');
        $title_sc = $request->input('title_sc');
        $category= $request->input('category');
        $img = $imageName;
        $text_en = $request->input('text_en');
        $text_tc = $request->input('text_tc');
        $text_sc = $request->input('text_sc');
        $sortid = $request->input('sortid');
        $articlesObject = new Article();
        $result=$articlesObject->UpdateArticleById($id,$title_en,$title_tc,$title_sc,$img,$text_en,$text_tc,$text_sc,$sortid);
        return redirect('/menu_list/'.$category);
        // session(['webpage_msg' =>'Update completed']);
        //return redirect('/menu_mod/'.$id);
    }
    public  function genLeftMenu($menu_main)
    {
        $menu_code_html='';
        foreach ($menu_main as $menu_main_item) {
            $menu_code_html .= '<li><a><i class="fa fa-desktop"></i>'.$menu_main_item->name_en.'<span class="fa fa-chevron-down"></span></a>';
            $menu_code_html .= '<ul class="nav child_menu">';

            foreach ($menu_main_item->submenus as $submenu_item){
               // if ($menu_main_item->submenus == 1) {
                    $menu_code_html .= '<li><a href="'.$submenu_item->url.'">'.$submenu_item->name_en.'</a></li>';
               // }
            }

            $menu_code_html .= '</ul>';
            $menu_code_html .= '</li>';
        }
        return $menu_code_html;
    }
    public  function user_login(Request $request){
        $UserAdminUserM=new User();
        $logID = $request->input('pusername');
        $pwd = $request->input('ppassword');

        $UserAdminUser=$UserAdminUserM->admin_user_login($logID,$pwd);
        if(count($UserAdminUser)>0){
            session(['smartwebsiteauthenticate' =>'authenticate20210125']);
        }else{
            session(['smartwebsiteauthenticate' =>'']);
        }
        return response()->json($UserAdminUser);
    }

    public function client_page_list()
    {

        if(session('webpage_msg')==null){
            redirect('/smartadmin/');
        }
        else{
            if(session('webpage_msg') !="authenticate20210125"){
                redirect('/smartadmin/');
            }
        }
        $language='en';
        $postType=1001;

        $data['page_title']="Appointments List";
        //$category=1;

        $Navigations = new Navigation();
        $page_menus=$Navigations->GetAdminNav(0,$language);
        foreach ($page_menus as $page_menu) {
            $page_menu->submenus =$Navigations->GetAdminNav($page_menu->nav_id,$language);
        }

        $data['page_menus']=$this->genLeftMenu($page_menus);

        $articlesObject = new Article();
        $clients=$articlesObject->GetClients();
        $data['clients']= $clients;
        $data['admin_name']= config('constants.ADMIN_NAME');
        return view('production/client_page_list')->with('page_data',$data);;

    }

    public function admin_users_import()
    {
        //$adminuser=Excel::import(new UsersImport,storage_path('excel/adminusers.xlsx'));
       // var_dump($adminuser);
        echo storage_path('excel/adminusers.xlsx');

    }
}
