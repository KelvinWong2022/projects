<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Navigation;
use App\Models\Language;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Store;
use Illuminate\Support\Facades\URL;
use Session;
use DateTime;
class StoreController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
       echo "Shopping Mall";
    }
    public function add_notice(){
        $data['articles']= "";

        return view('add_notice')->with('page_data',$data);
    } 
     public function add_notice_save(Request $request){

         $link_code="KelvinDemo";
         $product_id=123456;
         $type="e";
         $element="radio";
         $op_name="date" ;
         $op_value="2021-04-16";
         $sort_id=100;


         $storeObject = new Store();
         $data['home_news']=$storeObject->school_notice_option_add($link_code, $product_id, $type, $element, $op_name, $op_value, $sort_id);
         echo $data['home_news'];
    } 
}
