<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use DateTime;

class Store extends Model
{
    use HasFactory;

    //If you wish to use a non-incrementing or a non-numeric primary
    //public $incrementing = false;
    //If your model's primary key is not an integer
    // protected $keyType = 'string';
    public $timestamps = false;


    public function school_notice_option_add($link_code, $product_id, $type, $element, $op_name, $op_value, $sort_id){
        $date = new DateTime();
        $current_date_str = $date->format('YmdHis');
       $Navs = DB::connection('mysql_store')->table('e_school_notice_option')
            //->select($fields)
             ->where('link_code',$link_code)
             ->where('type',$type)
             ->delete();

        // if($lg=="en"){
        //     $fields=array('*');
        // }
        // elseif ($lg=="sc") {
        //     $fields=array('*');
        // }
        // else{
        //     $fields=array('*');
        // }
        // //id, link_code, product_id, `type`, element, op_name, op_value, sort_id
        // $Navs = DB::connection('mysql_store')->table('e_school_notice_option')
        //     //->select($fields)
        //      ->where('link_code',"kelvindemo")
        //      ->where('type','t')
        //     // ->where('deleted',0)
        //     // ->orderBy('sortid', 'ASC')
        //    // ->get();
        //      ->count();
        //return $Navs;
        if($type=="e"){
            $element='0';
            $op_name='image';
            $op_value=$link_code.$current_date_str.'.jpg';
        }

        $insertdata = array(
            'link_code' =>$link_code
            ,'product_id' => $product_id
            ,'type' => $type
            ,'element' =>$element
            ,'type' =>$type
            ,'op_name' =>$op_name
            ,'op_value'=> $op_value
            ,'sort_id' => $sort_id
          
        );
        $affected = DB::connection('mysql_store')->table('e_school_notice_option')
            ->insert($insertdata);
             return "Done";
    }
   
}
