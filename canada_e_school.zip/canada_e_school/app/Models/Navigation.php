<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Navigation extends Model
{
    use HasFactory;
    protected $table = 'navigation';
    protected $primaryKey = 'nav_id';
    //If you wish to use a non-incrementing or a non-numeric primary
        //public $incrementing = false;
    //If your model's primary key is not an integer
       // protected $keyType = 'string';
    public $timestamps = false;

     function  GetNav($fid,$lg="tc"){
         if($lg=="en"){
             $fields=array('*','name_en AS menu_name');
         }
         elseif ($lg=="sc") {
             $fields=array('*','name_sc AS menu_name');
         }
         else{
             $fields=array('*','name_tc AS menu_name');
         }

//         $this->db->where('fid', $fid);
//         $this->db->where('nav_show', 1);
//         $this->db->where('deleted', 0);
//         $this->db->order_by('sortid', 'ASC');
         $Navs = DB::table('navigation')
            ->select($fields)
            ->where('fid',$fid)
             ->where('nav_show',1)
             ->where('deleted',0)
             ->orderBy('sortid', 'ASC')
            // ->where('stu_name', 'Joe')
            ->get();
         //return $Navs;
        return $Navs->toArray();
    }

    function  GetAdminNav($fid,$lg){
        if($lg=="en"){
            $fields=array('*','name_en AS menu_name');
        }
        elseif ($lg=="sc") {
            $fields=array('*','name_sc AS menu_name');
        }
        else{
            $fields=array('*','name_tc AS menu_name');
        }

        $Navs = DB::table('admin_navigation')
            ->select($fields)
            ->where('fid',$fid)
            ->where('deleted',0)
            ->orderBy('sortid', 'ASC')
            // ->where('stu_name', 'Joe')
            ->get();
        //return $Navs;
        return $Navs->toArray();
    }
}
