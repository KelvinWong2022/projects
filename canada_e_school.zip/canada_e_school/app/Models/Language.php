<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Language extends Model
{
    public function header_section($lg){
        if($lg=="en"){
            $header=array(
                "first_name"=>"First Name *",
                "last_name"=>"Last Name *",
                "email"=>"Email Address *",
                "mobile"=>"Mobile Number *",
                "destination"=>"Your preferred study destination *",
                "counselling"=>"Preferred mode of counselling *",
                "permission"=>"MySmart Education & Canada eSchool will not share your details with others without your permission:",
                "policy"=>" *I agree to Smart Education Terms, privacy policy and Personal Information Collection Statement (PICS). *",
                "phonesms"=>"Please contact me by phone, email or SMS to assist with my enquiry.",
                "information"=>"I’d love to get useful information from Smart Education about study abroad, scholarships, English Language Development and TOEFL.",
                "country_1"=>"Australia",
                "country_2"=>"Canada",
                "country_3"=>"New Zealand",
                "country_4"=>"United Kingdom",
                "country_5"=>"United States",
                "country_6"=>"Ireland",
                "counselling_0"=>"Please select",
                "counselling_1"=>"In-person",
                "counselling_2"=>"Virtual Counselling",
                "submit"=>"Submit",
                "btn_appointment"=>"Appointment",


            );
            return $header;
        }else{
            $header=array(
                "first_name"=>"名字*",
                "last_name"=>"姓氏*",
                "email"=>"電郵地址*",
                "mobile"=>"手提電話*",
                "destination"=>"你首選升學地點*",
                "counselling"=>"首選擇咨詢方式*",
                "permission"=>"在未得到你的同意前，聰穎教育和Canada eSchool不會與他人分享你的個人資料：",
                "policy"=>"*我同意聰穎教育和Canada eSchool的條款、私隱政策及收集個人資料聲明。",
                "phonesms"=>"請以電話、短訊或電郵聯絡本人以協助有關海外升學的諮詢。",
                "information"=>"我想要收到聰穎教育和Canada eSchool有關海外升學、獎學金、英語培訓及IELTS的相關實用推廣資訊",
                "submit"=>"送出資料",
                "country_1"=>"澳洲",
                "country_2"=>"加拿大",
                "country_3"=>"新西蘭",
                "country_4"=>"英國",
                "country_5"=>"美國",
                "country_6"=>"愛爾蘭",
                "counselling_0"=>"請選擇",
                "counselling_1"=>"親身到訪",
                "counselling_2"=>"視像形式",
                "btn_appointment"=>"預約",

            );
            return $header;
        }

    }

}
