<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Article extends Model
{
    use HasFactory;
    protected $table = 'articles';
    protected $primaryKey = 'id';
    //If you wish to use a non-incrementing or a non-numeric primary
    //public $incrementing = false;
    //If your model's primary key is not an integer
    // protected $keyType = 'string';
    public $timestamps = false;


    public function GetArticleList($postType,$category,$lg){

        if($lg=="en"){
            $fields=array('*','title_en as title', 'text_en as content');
        }
        elseif ($lg=="sc") {
            $fields=array('*','title_sc as title', 'text_sc as content');
        }
        else{
            $fields=array('*','title_tc as title', 'text_tc as content');
        }
        $Navs = DB::table('articles')
            ->select($fields)
            ->where('type',$postType)
            ->where('category',$category)
            ->where('deleted',0)
            ->orderBy('sortid', 'ASC')
            ->get();
        //return $Navs;
        return $Navs;
    }
    public function GetArticleByIdLg($id,$lg){
        if($lg=="en"){
            $fields=array('*','title_en as title', 'text_en as content');
        }
        elseif ($lg=="sc") {
            $fields=array('*','title_sc as title', 'text_sc as content');
        }
        else{
            $fields=array('*','title_tc as title', 'text_tc as content');
        }
        $Navs = DB::table('articles')
            ->select($fields)
            ->where('id',$id)
            ->get();
        //return $Navs;
        return $Navs->toArray();
    }
    public function GetArticleById($id){
        $Navs = DB::table('articles')
            ->select('*')
            ->where('id',$id)
            ->get();
        //return $Navs;
        return $Navs->toArray();
    }
    public function AddArticle($title_en,$title_tc,$title_sc,$img,$category,$text_en,$text_tc,$text_sc,$sort_id){
        $insertdata = array(
            'title_en' =>$title_en
        ,'title_tc' => $title_tc
        ,'title_sc' => $title_sc
        ,'img' =>$img
        ,'type' =>1001
        ,'category' =>$category
        ,'adate'=> date('Y-m-d H:i:s')
        ,'text_en' => $text_en
        ,'text_tc' => $text_tc
        ,'text_sc' => $text_sc
        ,'sortid' => $sort_id
        ,'sortid' => $sort_id
        );
        $affected = DB::table('articles')
            ->insert($insertdata);
        return $affected;
    }
    public function UpdateArticleById($articleid,$title_en,$title_tc,$title_sc,$img,$text_en,$text_tc,$text_sc,$sort_id){
        $updatedata = array(
            'title_en' =>$title_en
            ,'title_tc' => $title_tc
            ,'title_sc' => $title_sc
            ,'img' =>$img
           // ,'category' =>$category
            ,'text_en' => $text_en
            ,'text_tc' => $text_tc
            ,'text_sc' => $text_sc
            ,'sortid' => $sort_id
        );
        $affected = DB::table('articles')
            ->where('id', $articleid)
            ->update($updatedata);
        return $affected;
    }

    public function client_add($first_name,$last_name,$email,$Telephone,$destination,$counselling,$agree_policy,$agree_by_phone,$agree_info){
        $insertdata = array(
            'first_name' =>$first_name
        ,'last_name' => $last_name
        ,'email' => $email
        ,'telephone' =>$Telephone
        ,'destination' =>$destination
        ,'counselling' =>$counselling
        ,'agree_policy' => $agree_policy
        ,'agree_by_phone' => $agree_by_phone
        ,'agree_info' => $agree_info
        ,'status' => 1
        ,'create_time'=> date('Y-m-d H:i:s')
        );
        $affected = DB::table('client_reg')
            ->insert($insertdata);
        return $affected;
    }

    public function GetClients(){

        $Navs = DB::table('client_reg')
            ->select('*')
            ->orderBy('create_time', 'DESC')
            ->get();
        //return $Navs;
        return $Navs;
    }
}
