@include('header')
<style>
    .page_top_bar_section {

        background-color: #666;
        height:120px; /* You must set a specified height */
        background-position: center; /* Center the image */
        background-repeat: no-repeat; /* Do not repeat the image */
        background-size: cover; /* Resize the background image to cover the entire container */
    }
    .page_top_bar_section_title{
        float:left; width: 80%;
        color: #fff;
        font-size: 3rem;
        font-weight: 800;
    }
    .container_content {
        bottom: 0;
        background: rgb(0, 0, 0); /* Fallback color */
        background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
        width: 100%;
        color: #fff;
        font-size: 3rem;
        font-weight: 800;
        padding-left: 10%;
    }
</style>
<!--Page top bar-->
<div class="row page_top_bar_section" id="page_top_bar_section_id">
    <div id="text_top_image" v-bind:class="{container_content:isActive}">
        <span>{{Str::upper($page_data['page_article']->title_en)}}</span>
    </div>

</div>

<script>
    var vue_top_bar_obj=new Vue({
        el:'#page_top_bar_section_id',
        data:{
            isActive:true
        }
    })
    setTopbarHeight();
    $( window ).resize(function() {
        setTopbarHeight();
    });
    function setTopbarHeight() {
        var page_top_bar_w=$('#page_top_bar_section_id').width();
        var page_top_bar_h=page_top_bar_w/5;
        $('#page_top_bar_section_id').height(page_top_bar_h);
        $('#text_top_image').height(page_top_bar_h);
        var text_margin=(page_top_bar_h-$('#page_top_bar_section_title').height())/2;
        $('#text_top_image').css('padding-top',text_margin);
        // vue_top_bar_obj.isActive=false;
        // vue_top_bar_obj.isActive=true;
        //$("#text_top_image" ).toggleClass("container_content","container_content_2" );
        // $('#text_top_image').removeClass('container_content');
        // $( "#text_top_image" ).addClass("container_content");
    }

    $('#page_top_bar_section_id').css('background-image', 'url(/public/images/{{$page_data['page_article']->img}})');
</script>
<!--Page top bar-->

<!--Blog Section-->
<section class="blog-section style-two">
    <div class="container">
        <div class="row">
            @foreach ($page_data['home_news'] as $news_item)
              @if ( $loop->index==3)
                </div>
                <div class="row">
               @endif
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="item-holder">
                    <div class="image-box">
                        <figure>
                            <a href="{{$news_item->url}}" target="_blank">
                                <img src="{{asset('/public/images/')}}/{{$news_item->img}}" alt="">
                            </a>
                        </figure>
                        <div class="date-box">
                            <span>{{ \Carbon\Carbon::parse($news_item->adate)->format('j F, Y') }}</span>
                        </div>
                    </div>
                    <div class="content-text">
                        <div class="sec-title" style="height: 165px;">
                            <a href="{{$news_item->url}}" target="_blank">
                                <h5>
                                    {{ \Illuminate\Support\Str::limit(strip_tags($news_item->title), 80, $end='...') }}
                                </h5></a>
                        </div>
                        <div class="text">
                            <p>
                                {{ \Illuminate\Support\Str::limit(strip_tags($news_item->content), 250, $end='...') }}

                            </p>
                        </div>

                    </div>
                </div>
            </div>
            @endforeach
        </div>

    </div>
</section>
<!--End Blog Section-->

@include('footer')