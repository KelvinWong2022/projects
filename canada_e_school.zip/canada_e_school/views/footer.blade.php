<!--  container-fluid -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".header-top"><span class="icon fa fa-angle-up"></span></div>

<script src="{{ asset('public/html/js/jquery.js') }}"></script>
<script src="{{ asset('public/html/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('public/html/js/jquery.fancybox.pack.js') }}"></script>
<script src="{{ asset('public/html/js/jquery.fancybox-media.js') }}"></script>
<!--<script src="js/html5lightbox.js"></script>-->
<script src="{{ asset('public/html/js/isotope.js') }}"></script>

<!-- revolution slider js -->
<script src="{{ asset('public/html/assets/revolution/js/jquery.themepunch.tools.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/jquery.themepunch.revolution.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.actions.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.carousel.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.kenburn.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.migration.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.navigation.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.parallax.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
<script src="{{ asset('public/html/assets/revolution/js/extensions/revolution.extension.video.min.js') }}"></script>

<script src="{{ asset('public/html/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('public/html/js/validate.js') }}"></script>
<script src="{{ asset('public/html/js/wow.js') }}"></script>

<!-- bxslider -->
<script src="{{ asset('public/html/js/jquery.countTo.js') }}"></script>

<script src="{{ asset('public/html/js/script.js') }}"></script>
</body>
</html>
<div class="container-fluid" style="padding: 0px 5px 5px 5px;">
    <!-- row -->
    <div class="row">
        <div class="col"><!-- col -->
            <div style="width: 100%;height: 50px;line-height: 50px;background-color: #203864;color: #fff; text-align: center">
                Copyright © 2021 by Smart Education. All rights reserved.
            </div>
        </div><!-- col -->
    </div>  <!-- row -->
</div><!--  container-fluid -->
