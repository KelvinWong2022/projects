@include('header_bk')
<style>
    .div_page_slider{
        width: 100%;
        background-color: #ccc;
    }
    .main_content_container{
        margin: auto;
        width: 80%;
    }
    .tbl_border_white td {
        border: 1px solid #ccc;
        border-collapse: collapse;
    }



    .ossd_title_caption{
        margin: auto;
        width: 20%;
        height: 50px;
        line-height: 50px;
        font-size: 28px;
        color: #fff;
        border-radius: 5px;
        background-color: #203864;
        text-align: center;
    }

    .Teaching_OCT{
        margin: auto;
        width: 80%;
        border:solid 3px #ccc;
        text-align: center;
        padding: 10px;
    }

    .Teaching_OCT_button{
        margin: auto;
        width: 70%;
    }
    /*ul*/

    .after-box {
        clear: left;
    }
    .active{
        background-color: #ff1c1c;
    }
    .toefl_itp_section{
        margin: auto;
        width: 70%;
        text-align: center;
    }
    .toefl_itp_section_text{
        margin: auto;
        width: 70%;
        border:solid 1px #ccc;
        padding: 10px;
    }
    .news_swiper_div{
        width:99%;
        border: solid 1px #ccc;
 
        
    }
    .top_banner_block{
        width: 100%;
        text-align: center;
        background-position: center; /* Center the image */
        background-repeat: no-repeat; /* Do not repeat the image */
        background-size: cover; /* Resize the background image to cover the entire container */
    }
    .top_banner_block_text{
        margin: 0 auto;
        width: 50%;
        font-size: 48px;
        color: #fff;
        text-shadow: 2px 0 0 #fff, -2px 0 0 #203864, 0 2px 0 #203864, 0 -2px 0 #203864, 1px 1px #203864, -1px -1px 0 #203864, 1px -1px 0 #203864, -1px 1px 0 #203864;
        -moz-text-shadow:2px 0 0 #203864, -2px 0 0 #203864, 0 2px 0 #203864, 0 -2px 0 #203864, 1px 1px #203864, -1px -1px 0 #203864, 1px -1px 0 #203864, -1px 1px 0 #203864;
        -webkit-text-shadow: 2px 0 0 #203864, -2px 0 0 #203864, 0 2px 0 #203864, 0 -2px 0 #203864, 1px 1px #203864, -1px -1px 0 #203864, 1px -1px 0 #203864, -1px 1px 0 #203864;
    }
    #OSSD {
        width: 100%;
        height: auto;
        background-color: #223962;
        margin: auto;
        text-align: center;
        padding-bottom:50px;color: #FFF;font-size:18px;

    }

    #OSSD h2 {
        color: #FFF;
        font-weight: 300;
        font-size: 36px;
        padding-bottom: :36px;
        padding-top: 36px;
        margin: auto;
    }

    #OSSD table {
        width: 80%;
        margin: auto;
        border-collapse: collapse;
        max-width: 1000px;
    }

    #OSSD td {
        padding: 8px;
        color: #FFF;
        letter-spacing: 1.1px;
        transform: scale(1, 0.9);
        border-top: 1px #87848b solid;
    ;
        border-bottom: 1px #87848b solid;

    }

    #OSSD td:nth-child(3) {
        padding-right: 20px;
    }

    #OSSD td:nth-child(2) {
        padding-left: 20px;
    }

    #OSSD td:nth-child(1),
    #OSSD td:nth-child(4) {
        font-size: 40;
        width: 7%;
        font-weight: 900;
    }

    #OSSD td:nth-child(3),
    #OSSD td:nth-child(2) {
        width: 43%;
        border: 1px #87848b solid;
        font-size: 16px;
    }

    #OSSD td:nth-child(3),
    #OSSD td:nth-child(4) {
        text-align: right;
    }
</style>
<!--  container-fluid -->
<div class="container-fluid" style="padding: 0px 5px 5px 5px;">
    <!-- row -->
    <div class="row">
        <div class="col"><!-- col -->
            <div class="div_page_slider">
                <!-- Swiper -->
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="https://www.canadaeschool.ca/wp-content/uploads/2013/12/background4.jpg" style="width: 100%">
                        </div>
                        <div class="swiper-slide">
                            <img src="https://www.canadaeschool.ca/wp-content/uploads/2015/02/CPU_banner.jpg" style="width: 100%">
                        </div>
                    </div>
                    <!-- Add Arrows -->
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination"></div>
                </div>

                <!-- Swiper JS -->

                <!-- Initialize Swiper -->
                <script>
                    // top_banner_block_img_size();
                    // function top_banner_block_img_size(){
                    //     var  top_banner_b_w=$('.top_banner_block').width();
                    //     var  top_banner_h=top_banner_b_w /2.941;
                    //     $('.top_banner_block').height(top_banner_h);
                    //     $('#top_banner_block_1').css('background-image', 'url(https://www.canadaeschool.ca/wp-content/uploads/2013/12/background4.jpg)');
                    //     $('#top_banner_block_2').css('background-image', 'url(https://www.canadaeschool.ca/wp-content/uploads/2015/02/CPU_banner.jpg)');
                    //
                    // }

                    var swiper = new Swiper('.swiper-container', {
                        effect: 'fade',
                        fadeEffect: {
                            crossFade: true
                        },
                        navigation: {
                            nextEl: '.swiper-button-next',
                            prevEl: '.swiper-button-prev',
                        },
                        autoplay: {
                            delay: 4000,
                        },
                        pagination: {
                            el: '.swiper-pagination',
                            clickable: true,
                        },

                    });
                </script>
            </div>
        </div><!-- col -->
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->
    <div class="row"><!-- row -->
        <div style="font-family:'Open Sans',sans-serif;color:#485667;margin:25px;padding-bottom:25px;width:100%">
            <table style="width:80%;margin:auto;max-width:1000px;">
                <tr>
                    <td style="width:33%;font-size:36px;text-align: right;padding-right:35px;line-height: 1.3;color:#2e75b6">
                        Globally<br>
                        Recognized
                    </td>
                    <td style="width:66%;font-size:24px;padding-right:25px;line-height: 1.3;color:#485667;">
                        Don't want to worry about DSE scores?<br>
                        <b>Study the OSSD Diploma</b> in Hong Kong!<br>
                        Complete the course as quickly as 6 months
                        and <b>directly apply to universities both local and overseas!</b>
                    </td>
                </tr>
            </table>
        </div>
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->
    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div id="OSSD">
                <h2>OSSD</h2><br>
                <table style="">
                    <tr>
                        <td>01</td>
                        <td>Ontario Certified High School<br>Based in Hamilton, Ontario</td>
                        <td>Authorized by MOE to grant<br>credits & OSSD</td>
                        <td>03</td>
                    </tr>
                    <tr>
                        <td>02</td>
                        <td>40+ internationally recognized<br>courses for Grade 9-12</td>
                        <td>100% Taught By<br>Ontario Certified Teachers - OCT</td>
                        <td>04</td>
                    </tr>

                </table>
                <br>
                <hr style="width:55%;max-width:800px">
                <br>
                <div class="row" style="max-width:1100px;margin:auto;">
                    <div class="col-md-6"><img src="https://canadaeschool.mysmartedu.com/html/images/ossd_01.png" style="width:90%"></div>
                    <div class="col-md-6">
                        <div style="width:90%;margin:auto;line-height: 1.6;vertical-align: middle;text-align: justify;">
                            <br>Smart Education Co. Ltd. is the leading provider of high quality and innovative e-learning solutions in Greater China. We have expanded into overseas
                            studies and university preparation since 2019.
                            Educational Testing Service’s (ETS) official representative of the TOEIC and TOEFL tests in HK, Macau and South
                            China.

                        </div>
                    </div>

                </div>
            </div>
        </div><!-- col -->
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div style="width: 100px;height: 20px;"></div>
            <div class="ossd_title_caption">
                Canada E School
            </div>
            <div style="width: 100px;height: 10px;"></div>
            <div style="width: 100%; ">
                <div style="float: left;width: 15%;">
                    &nbsp;
                </div>
                <div style="float: left;width: 70%;border: solid #ccc 1px; padding: 10px;">
                    {!! $page_data['home_sections'][3]->content !!}
                </div>
                <div style="float: left;width: 15%;">
                    &nbsp;
                </div>
                <div class="after-box"></div>
            </div>
        </div><!-- col -->
    </div>  <!-- row -->


    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->

            <div style="width: 100px;height: 20px;"></div>
            <div class="ossd_title_caption">
                NEWS
            </div>
            <div style="width: 100px;height: 10px;"></div>
            <div style="margin: 0 auto;width: 70%;">
                <!-- Swiper -->
                <div class="swiper-container" id="swiper-container-small">
                    <div class="swiper-wrapper">

                        <div class="swiper-slide">
                            <div class="news_swiper_div">
                                <img src="{{asset('/public/images/gov_canada-696x464.jpg')}}" style="width: 100%">

                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="news_swiper_div">
                                <img src="{{asset('/public/images/gov_canada-696x464.jpg')}}" style="width: 100%">

                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="news_swiper_div">
                                <img src="{{asset('/public/images/gov_canada-696x464.jpg')}}" style="width: 100%">

                            </div>
                        </div>


                    </div>
                    <!-- Add Arrows -->
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>

            <script>
                var swiper_small = new Swiper('#swiper-container-small', {
                    slidesPerView:3,
                    spaceBetween: 10,

                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev',
                    },
                    mousewheel: true,
                    keyboard: true,
                });
            </script>

        </div><!-- col -->
    </div>  <!-- row -->
    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div style="width: 100px;height: 20px;"></div>
            <div class="ossd_title_caption">
                TOEFL ITP
            </div>
            <div style="width: 100px;height: 10px;"></div>

            <div style="width: 100px;height: 10px;"></div>
            <div class="toefl_itp_section_text" style="text-align: left;">
                {!! $page_data['home_sections'][7]->content !!}
            </div>
        </div><!-- col -->
    </div>  <!-- row -->


    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->
</div><!--  container-fluid -->
<script type="text/javascript" src="{{ asset('public/js/pages/page_index.js') }}"></script>
<script type="text/javascript">
  
    news_block_img_size();
    $( window ).resize(function() {
   news_block_img_size();
});
    function news_block_img_size(){
        var news_b_w=$('.news_swiper_div').width();
        var news_b_h=news_b_w /1.5;
    
        $('.news_swiper_div').height(news_b_h);
    }

</script>
@include('footer')