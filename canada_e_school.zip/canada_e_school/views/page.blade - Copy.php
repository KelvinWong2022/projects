@include('header')
<style>
    .new_pg_top_banner_img_bg {
        height: 250px;
        line-height: 250px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
    .new_pg_top_banner_caption {
        padding-left: 20px;
        font-size: 36px;
        color: #fff;
        font-weight: 700;
    }
    .page_div_caption{
        float: left;width: 70%;
        text-align: center;
        font-size: 1.5vw;
        font-weight: bold;
        margin-bottom: 1vw;
    }
    .page_div_content{
        float: left;
        width: 70%;
        color: #203864;
        padding: 15px;
    }
    .page_div_content span{

    }

</style>
<!--  container-fluid -->
<div class="container-fluid" style="padding: 0px 5px 5px 5px;">
    <!-- row -->
    <div class="row">
        <div class="col">
        <div class="new_pg_top_banner_img_bg" style="background-image: url(https://canadaeschool.mysmartedu.com/public/images/canada-e-school-small-banner.jpg);" id="new_pg_top_banner_div">
            <div class="new_pg_top_banner_caption" id="new_pg_top_banner_caption_div">Canada eSchool</div>
        </div>
        </div>
    </div>  <!-- row -->
    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="row_section_space_20"></div>
        </div><!-- col -->
    </div>  <!-- row -->

    <!-- row -->
    <div class="row">
        <div class="col">
            <div style="width: 100%; ">
                <div style="float: left;width: 15%;">
                    &nbsp;
                </div>
                <div class="page_div_content">
                  {!! $page_data['page_article']->content !!}
                </div>
                <div style="float: left;width: 15%;">
                    &nbsp;
                </div>
                <div class="after-box"></div>
            </div>
        </div>
    </div>  <!-- row -->
</div><!--  container-fluid -->
@include('footer')