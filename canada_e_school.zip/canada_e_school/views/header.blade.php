<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="在港修讀OSSD中學畢業文憑課程不要再為DSE成績煩惱 !最快半年完成課程,直接報讀本地及海外大學.安省高中畢業文憑 (OSSD) 是一項國際認可的證書Canada eSchool是一所位於安大略省的註冊中學，專門為全球學生提供遙距教育課程。 院校獲安大略省教育部 (MOE)認可，每年開辦超過40項課程，適合各種學生的學習需求。" />
    <meta name="keywords" content="OSSD中學畢業文憑課程遙距教育課程,加拿大升學,加拿大留學,OSSD,升學 agent" />
    <title>OSSD中學畢業文憑遙距教育課程|Canada eSchool|加拿大讀書|海外升學</title>
    <script src="{{ asset('public/js/jquery-2.2.4.js') }}" type="text/javascript"></script>
    <script  src="{{ asset('public/js/underscore-min.js') }}"  type="text/javascript"></script>
    <script  src="{{ asset('public/js/vue.js') }}"  type="text/javascript"></script>
    <!-- Stylesheets -->
    <link href="{{ asset('public/html/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('public/html/css/responsive.css') }}" rel="stylesheet">
    <link href="{{ asset('public/html/css/style.css?v=20210219') }}" rel="stylesheet">

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!--Favicon-->
    <link rel="shortcut icon" href="{{ asset('public/html/images/favicon.ico') }}" type="image/x-icon">
    <link rel="icon" href="{{ asset('public/html/images/favicon.ico') }}" type="image/x-icon">

    <!--Vertical-->
    <link rel="stylesheet" media="screen and (max-width: 749px) and (orientation:portrait)" href="{{ asset('public/css/pages/page_main_style_699_v.css')}}">
    <!--Horizontal-->
    <link rel="stylesheet" media="screen and (max-width: 749px)  and (orientation:landscape)" href="{{ asset('public/css/pages/page_main_style_699_h.css')}}">
    <!--Vertical-->
    <link rel="stylesheet" media="screen and (min-width: 750px) and (max-width: 1200px) and (orientation:portrait)" href="{{ asset('public/css/pages/page_main_style_700_v.css')}}">
    <!--Horizontal-->
    <link rel="stylesheet" media="screen and (min-width: 750px)  and (max-width: 1200px) and (orientation:landscape)" href="{{ asset('public/css/pages/page_main_style_700_h.css')}}">
    <link rel="stylesheet" media="screen and (min-width:1201px)" href="{{ asset('public/css/pages/page_main_style_1200.css')}}">

    <style>
	
         html {
  font-size:16px;
}
        #OSSD {
            width: 100%;
            height: auto;

            margin: auto;
            text-align: center;
            padding-bottom:50px;color: #FFF;font-size:18px;

        }
#stuff
{
position: fixed;
bottom: 50px;
right: 10px;
z-index: 888;

}
        #OSSD h2 {
            color: #000;
            font-weight: 300;
            font-size: 36px;
            padding-bottom: :36px;
            padding-top: 36px;
            margin: auto;
        }

        #OSSD table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            max-width: 1000px;
        }

        #OSSD td {
            padding: 8px;
            color: #fff;
            letter-spacing: 1.1px;
            transform: scale(1, 0.9);
            border-top: 1px #87848b solid;
            border-bottom: 1px #87848b solid;

        }

        #OSSD td:nth-child(3) {
            padding-right: 20px;
        }

        #OSSD td:nth-child(2) {
            padding-left: 20px;
        }

        #OSSD td:nth-child(1)
        {
            font-size: 40px;
            width: 7%;

            font-weight: 900;
        }
        #OSSD td:nth-child(3) {
            font-size: 40px;
            width: 7%;
            border: 1px #87848b solid;
            font-weight: 900;
        }

        #OSSD td:nth-child(4)
        {
            width: 43%;

            font-size: 20px;
        }
        #OSSD td:nth-child(2) {
            width: 43%;
            border: 1px #87848b solid;
            font-size: 20px;
        }

        #OSSD td:nth-child(3),
        #OSSD td:nth-child(4) {
            text-align: center;
        }


        .language_btn{

        }
        .language_btn a {
            color: white;
        }
        .language_btn a:hover {
            color: white;
            font-weight: 600;
        }
         .lblmsginput{
             color:red;
         }
    </style>

    <script type="text/javascript">
        $( document ).ready(function() {
            $("#lbl_first_name").hide();
            $("#lbl_last_name").hide();
            $("#lbl_email").hide();
            $("#lbl_mobile_number").hide();
            $("#lbl_slt_counselling").hide();
            $("#lbl_slt_terms").hide();
            $("#lbl_email_check").hide();

            $( "#btn_appointment" ).click(function() {
                $('#modal_appointment').modal('toggle');
            });





            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
//----------------------------------------------------------------
            $('#btn_appointment_save').click(function () {
                $("#lbl_first_name").hide();
                $("#lbl_last_name").hide();
                $("#lbl_email").hide();
                $("#lbl_mobile_number").hide();
                $("#lbl_slt_counselling").hide();
                $("#lbl_slt_terms").hide();
                $("#lbl_email_check").hide();


                var weburl=$("#hdwebsiteurl").val();

                var tb_first_name = $("#tb_first_name").val();
                var tb_last_name = $("#tb_last_name").val();
                var tb_email = $("#tb_email").val();
                var tb_mobile_number = $("#tb_mobile_number").val();
                var slt_country = $("#slt_country").val();
                var slt_counselling = $("#slt_counselling").val();
                var ck_policy=$('#ck_policy').is(":checked");
                var ck_phone=$('#ck_phone').is(":checked");
                var ck_info=$('#ck_info').is(":checked");

                //-------------------------------------------------------------------
                if(tb_first_name==""){
                    $("#lbl_first_name").show();
                    return false;
                }

                if(tb_last_name==""){
                    $("#lbl_last_name").show();
                    return false;
                }

                if(tb_email==""){
                    $("#lbl_email").show();
                    return false;
                }
                else{
                    if(isEmail(tb_email)==false){
                        $("#lbl_email_check").show();
                        return false;
                    }
                }
                if(tb_mobile_number==""){
                    $("#lbl_mobile_number").show();
                    return false;
                }
                if(slt_counselling=="0"){
                    $("#lbl_slt_counselling").show();
                    return false;
                }
                if(ck_policy==false){
                    $("#lbl_slt_terms").show();
                    return false;
                }
                var postdata={
                    first_name:tb_first_name
                    ,last_name:tb_last_name
                    ,email:tb_email
                    ,mobile_number:tb_mobile_number
                    ,country:slt_country
                    ,counselling:slt_counselling
                    ,policy:ck_policy
                    ,phone:ck_phone
                    ,info:ck_info
                };

                //ajax------------------------------------------
                $.ajax({
                    url: weburl+"/index.php/client_reg",
                    type: 'post',
                    data:postdata,
                    dataType: 'json',
                    beforeSend: function() {
                        $('#spinner_pro_image').show();
                        $('#btnlogin').prop( "disabled", true );
                    },
                    complete: function() {
                        $('#spinner_pro_image').hide();
                        $('#btnlogin').prop( "disabled", false );
                    },
                    success: function(data) {
                        //console.log(data);
                        if(data){
                            $("#result_msg").html("Your data has been saved, we will contact you.");
                        }
                        else{
                            $("#result_msg").html("Your data has been saved unsuccessfully.");
                        }


                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
                //ajax------------------------------------------

            });

            function isEmail(email) {
                var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                return regex.test(email);
            }

        
        });
    </script>
</head>

<body>

<div id="stuff">
    <a href="https://wa.me/85263110380">
    <img src="https://store.mysmartedu.com/image/ContactUs_ENG100.png">
    </a>
</div>
<div class="page-wrapper">
    <!-- Modal -->
    <div class="modal fade" id="modal_appointment" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true" style="z-index:9999999; ">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_first_name" name="tb_first_name" placeholder="{{$page_data['appointment_text']['first_name']}}">
                        <label id="lbl_first_name" class="lblmsginput">We’d love to know your name!</label>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_last_name" name="tb_last_name" placeholder="{{$page_data['appointment_text']['last_name']}}">
                        <label id="lbl_last_name" class="lblmsginput">Please enter your last name!</label>
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_email" name="tb_email" placeholder="{{$page_data['appointment_text']['email']}}">
                        <label id="lbl_email" class="lblmsginput">We need an email we can contact you on!</label>
                        <label id="lbl_email_check" class="lblmsginput">Please enter a valid email!</label>

                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_mobile_number" name="tb_mobile_number" placeholder="{{$page_data['appointment_text']['mobile']}}">
                        <label id="lbl_mobile_number" class="lblmsginput">Please enter a valid phone number!</label>
                    </div>
                    <div class="form-group">
                        <label>{{$page_data['appointment_text']['destination']}}</label>
                        <select id="slt_country" name="slt_country" class="form-control">
                            <option>{{$page_data['appointment_text']['country_1']}}</option>
                            <option>{{$page_data['appointment_text']['country_2']}}</option>
                            <option>{{$page_data['appointment_text']['country_3']}}</option>
                            <option>{{$page_data['appointment_text']['country_4']}}</option>
                            <option>{{$page_data['appointment_text']['country_5']}}</option>
                            <option>{{$page_data['appointment_text']['country_6']}}</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{{$page_data['appointment_text']['counselling']}}</label>
                        <select id="slt_counselling" name="slt_counselling" class="form-control">
                            <option value="0">{{$page_data['appointment_text']['counselling_0']}}</option>
                            <option value="{{$page_data['appointment_text']['counselling_1']}}">{{$page_data['appointment_text']['counselling_1']}}</option>
                            <option value="{{$page_data['appointment_text']['counselling_2']}}">{{$page_data['appointment_text']['counselling_2']}}</option>
                        </select>
                        <label id="lbl_slt_counselling" class="lblmsginput">Please select your initial counselling!</label>
                    </div>
                    <div class="form-group">
                        <label>{{$page_data['appointment_text']['permission']}}</label>
                        <br>
                        <input id="ck_policy" name="ck_policy" type="checkbox" value="" >
                        {{$page_data['appointment_text']['policy']}}
                        <label id="lbl_slt_terms" class="lblmsginput">Please agree to our terms!</label>
                        <br>
                        <input id="ck_phone" name="ck_phone"  type="checkbox" value="" >
                        {{$page_data['appointment_text']['phonesms']}}
                        <br>
                        <input id="ck_info" name="ck_info"  type="checkbox" value="" >
                        {{$page_data['appointment_text']['information']}}

                    </div>
                </div>

                <div class="modal-footer">
                    <div class="spinner-border text-primary" id="spinner_pro_image" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                    <div id="result_msg" style="color: #ff1c1c;"></div>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id="btn_appointment_save" class="btn btn-primary">{{$page_data['appointment_text']['submit']}}</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->

    <!-- Preloader -->
    <div class="preloader"></div>
    <!-- Preloader -->

    <!--header top-->

    <div class="header-top">
        <div id="div_header_study_id" class="container clearfix">

        </div>
            <script type="text/javascript">
                console.log($(window).width())
                var header_study_code='';
                if($(window).width()>700){
                    header_study_code +='<div class="top-left">';
                    header_study_code +='<ul class="contact-links">';
                    header_study_code +='<li>Study in Australia</li>';
                    header_study_code +='<li>Study in Japan</li>';
                    header_study_code +='</ul>';
                    header_study_code +='</div>';
                    header_study_code +='<div class="top-right clearfix">';
                    header_study_code +='<div class="search_option language_btn">';
                    header_study_code +='<a href="https://canadaeschool.mysmartedu.com/index.php/clg/en">English</a>';
                    header_study_code +=' &nbsp; &nbsp;';
                    header_study_code +='<a href="https://canadaeschool.mysmartedu.com/index.php/clg/tc">繁體</a>';
                    header_study_code +='&nbsp; &nbsp;';
                    header_study_code +='<a href="https://canadaeschool.mysmartedu.com/index.php/clg/sc">简体</a>';
                    header_study_code +='</div>';
                    header_study_code +='</div>';
                }
                else{
                    header_study_code +=' <div style="float:left;width: 50%;">';
                    header_study_code +='<div class="form-group">';
                    header_study_code +='<select class="form-control" id="exampleFormControlSelect1">';
                    header_study_code +='<option>Other Countries</option>';
                    header_study_code +='<option>Study in Australia</option>';
                    header_study_code +='<option>Study in Japan</option>';
                    header_study_code +='</select>';
                    header_study_code +='</div>';
                    header_study_code +='</div>';
                    header_study_code +='<div style="float:left;width: 50%;">';
                    header_study_code +='<div class="search_option language_btn">';
                    header_study_code +='<a href="https://canadaeschool.mysmartedu.com/index.php/clg/en">English</a>';
                    header_study_code +=' &nbsp; &nbsp;';
                    header_study_code +='<a href="https://canadaeschool.mysmartedu.com/index.php/clg/tc">繁體</a>';
                    header_study_code +='&nbsp; &nbsp;';
                    header_study_code +='<a href="https://canadaeschool.mysmartedu.com/index.php/clg/sc">简体</a>';
                    header_study_code +='</div>';
                    header_study_code +='</div>';
                }


                $('#div_header_study_id').html(header_study_code);
            </script>
    </div>
    <!--header top-->



    <!--Main Header-->
    <header class="main-header sticky-header">
        <div class="container-fluid">
            <div class="logo">
                <figure>
                    <a href="/"><img src="{{ asset('public/images/canadaeschoollogo.png') }}" width="250" alt="" class="header_page_logo_img" ></a>
                </figure>
            </div>
            <div class="header-area clearfix">
                <nav class="main-menu">
                    <div class="navbar-header">
                        <!-- Toggle Button -->
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="navbar-collapse collapse clearfix">
                        <ul class="navigation clearfix">
                            @foreach ($page_data['main_menus'] as $main_menu)
                                @if ($main_menu->has_sub_menus === 0)
                                    <li><a href="{{$main_menu->url}}">{{$main_menu->menu_name}}</a></li>
                                @else
                                    <li class="dropdown"><a href="#">{{$main_menu->menu_name}}</a>
                                        <ul>
                                            @foreach ($main_menu->submenus as $submenu)
                                            <li><a href="{{$submenu->url}}">{{$submenu->menu_name}}</a></li>
                                            @endforeach
                                        </ul>
                                    </li>
                                @endif

                            @endforeach
                        </ul>
                    </div>
                </nav>
                <div class="link-button div_appointment">
                    <a href="#" id="btn_appointment" class="btn-style-one">{{$page_data['appointment_text']['btn_appointment']}}</a>
                </div>
            </div>
        </div>
    </header>
    <!--End Main Header -->