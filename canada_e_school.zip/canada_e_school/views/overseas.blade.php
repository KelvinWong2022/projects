@include('header')
<!--Page Title-->
<section class="page-title">
    <div class="container clearfix">
        <div class="title pull-left">
            <h4>Overseas Studies</h4>
        </div>
        <ul class="title-manu pull-right">
            <li><a href="index.html">home</a></li>
            <li>></li>
            <li>Overseas Studies</li>
        </ul>
    </div>
</section>
<!--End Page Title-->

<!--Finance Section-->
<section class="finance-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-xs-12">
                <div class="image-box">
                    <figure>
                        <img src="{{asset('/uploadimages/images/logo/SMART_LOGO2.png')}}" style="border: solid 1px #ccc; padding: 10px; border-radius: 5px;" alt="">
                    </figure>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-xs-12">
                <div class="content-box">
                    <div class="section-title">
                        <h2>ABOUT US</h2>
                    </div>
                    {!! $page_data['page_article']->content !!}
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Finance Section-->

<!--testimonials Style-->
<section class="testimonial-section">
    <div class="container">
        <div class="sec-title text-center">
            <h3>OUR SERVICES</h3>
           <div style="width: 100%; height: 20px;"></div>
            <img src="{{asset('/uploadimages/images/Picture1.png')}}" style="width: 100%;">
        </div>

    </div>
</section>
<!--End testimonials Style-->

@include('footer')