@include('header')

<!--Start rev slider wrapper-->
<section class="rev_slider_wrapper">
    <div id="slider1" class="rev_slider"  data-version="5.0">
        <ul>
            <li data-transition="fade">
                <img src="https://www.canadaeschool.ca/wp-content/uploads/2015/02/CPU_banner.jpg"  alt="" width="1920" height="650" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >

                <div class="tp-caption  tp-resizeme"
                     data-x="left" data-hoffset="15"
                     data-y="top" data-voffset="200"
                     data-transform_idle="o:1;"
                     data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                     data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                     data-mask_in="x:[100%];y:0;s:inherit;e:inherit;"
                     data-splitin="none"
                     data-splitout="none"
                     data-responsive_offset="on"
                     data-start="700">
                    <div class="slide-content-box">
                        <div class="slide_section_title">Why OSSD?</div>
                        <p>
                        <div class="slide_section_text">
                            <div class="slide_section_text_row">Ontario Certified High School Based in Hamilton, Ontario</div>
                            <div class="slide_section_text_row">40+ internationally recognized courses for Grade 9-12</div>
                            <div class="slide_section_text_row">Authorized by MOE to grant credits & OSSD</div>
                            <div class="slide_section_text_row">100% Taught By Ontario Certified Teachers - OCT</div>

                        </div>

                        </p>
                    </div>
                </div>
                <div class="tp-caption tp-resizeme"
                     data-x="left" data-hoffset="15"
                     data-y="top" data-voffset="380"
                     data-transform_idle="o:1;"
                     data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                     data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                     data-splitin="none"
                     data-splitout="none"
                     data-responsive_offset="on"
                     data-start="2300">
                    <div class="slide-content-box">

                    </div>
                </div>
            </li>
            <li data-transition="fade">
                <img src="https://www.canadaeschool.ca/wp-content/uploads/2013/12/background4.jpg"  alt="" width="1920" height="650" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >

                <div class="tp-caption  tp-resizeme"
                     data-x="left" data-hoffset="15"
                     data-y="top" data-voffset="200"
                     data-transform_idle="o:1;"
                     data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                     data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                     data-mask_in="x:[100%];y:0;s:inherit;e:inherit;"
                     data-splitin="none"
                     data-splitout="none"
                     data-responsive_offset="on"
                     data-start="700">
                    <div class="slide-content-box">
                        <div class="slide_section_title">Advantages of Canada eSchool</div>
                        <p>
                        <table>
                            <tr>
                                <td class="slide_section_space_td_1">&nbsp;</td>
                                <td>
                                    <div class="slide_section_text_row">Live Teaching by OCT Teachers</div>
                                    <div class="slide_section_text_row">Transferable credits</div>
                                    <div class="slide_section_text_row">No public examinations</div>
                                    <div class="slide_section_text_row">Personalized Study Plan</div>
                                </td>
                                <td class="slide_section_space_td_2">&nbsp;</td>
                                <td>
                                    <div class="slide_section_text_row">Begin anytime; work at your own pace</div>
                                    <div class="slide_section_text_row">70% Coursework + 30% Internal Exams</div>
                                    <div class="slide_section_text_row">Cost-conscious study option</div>
                                    <div class="slide_section_text_row">One-on-One Guidance</div>
                                </td>
                            </tr>
                        </table>
                        </p>
                    </div>
                </div>
                <div class="tp-caption tp-resizeme"
                     data-x="left" data-hoffset="15"
                     data-y="top" data-voffset="380"
                     data-transform_idle="o:1;"
                     data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                     data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                     data-splitin="none"
                     data-splitout="none"
                     data-responsive_offset="on"
                     data-start="2300">
                    <div class="slide-content-box">

                    </div>
                </div>
            </li>

        </ul>
    </div>
</section>
<!--End rev slider wrapper-->

<!--Wellcome Section-->
<section class="wellcome-section">
    <div class="container">
        <div class="section-title text-center">
            <div class="section_title_text">
                {!! $page_data['home_sections'][0]->title !!}
            </div>
            <h2></h2>
            <div class="section_content_text">
                {!! $page_data['home_sections'][0]->content !!}
            </div>
        </div>

    </div>
</section>
<!--End Wellcome Section-->


<!--Service Section-->
<section class="service-section" style="background-color: #203864; color: white;">
    <div class="container">
        <div class="section-title text-center">
            <div class="section_title_text" style="color: white">{!! $page_data['home_sections'][1]->title !!}</div>
            <img src="{{asset('/public/images/')}}/bd_2.png" alt="">
        </div>
        {!! $page_data['home_sections'][1]->content !!}
    </div>
</section>
<!--End Service Section-->


<!--team section-->
<section class="team-section">
    <div class="container">
        <div class="section-title text-center">
            <div class="section_title_text"> {!! $page_data['home_sections'][2]->title !!}</div>
            <h2></h2>
        </div>
        <div class="row">
            {!! $page_data['home_sections'][2]->content !!}
        </div>
    </div>
</section>
<!--End team section-->
<!--Blog Section-->
<section class="blog-section" style="background-color: #203864;padding-top:50px; ">
    <div class="container">
        <div class="section-title text-center">
            <div class="section_title_text" style="color:#fff;">Latest news</div>
            <img src="{{asset('/public/images/')}}/bd_2.png" alt="">
        </div>
        <div class="row">
            @foreach ($page_data['home_news'] as $news_item)
            @if ( $loop->index==3)
                </div>
                <div class="row">
               @endif
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="item-holder" style="background-color: white;">
                    <div class="image-box">
                        <figure>
                            <a href="{{$news_item->url}}" target="_blank">
                                <img src="{{asset('/public/images/')}}/{{$news_item->img}}" alt="">
                            </a>
                        </figure>
                        <div class="date-box">
                            <span>{{ \Carbon\Carbon::parse($news_item->adate)->format('j F, Y') }}</span>
                        </div>
                    </div>
                    <div class="content-text">
                        <div class="sec-title" style="height: 130px;">
                            <a href="{{$news_item->url}}" target="_blank">
                                <h5>
                                    {{ \Illuminate\Support\Str::limit(strip_tags($news_item->title), 80, $end='...') }}
                                </h5></a>
                        </div>
                        <div class="text" style="padding-bottom: 5px;">
                            <p>
                                {{ \Illuminate\Support\Str::limit(strip_tags($news_item->content), 250, $end='...') }}

                            </p>
                        </div>

                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
<!--End Blog Section-->

<!--Blog Section-->
<section class="blog-section">
    <div class="container">
        <div class="section-title text-center">
            <div class="section_title_text"> {!! $page_data['home_sections'][3]->title !!}</div>
            <h2></h2>
        </div>
        <div class="row">
            {!! $page_data['home_sections'][3]->content !!}
        </div>
    </div>
</section>
<!--End Blog Section-->








</div>
<!--End pagewrapper-->



@include('footer')