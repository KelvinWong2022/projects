<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Add E-Notice</title>
</head>
<body>
<h3>Add E-Notice</h3>

 <form action="add_notice_save" method="post" data-parsley-validate class="form-horizontal form-label-left"   enctype="multipart/form-data">
     @csrf <!-- {{ csrf_field() }} -->
	 <table>
 		<tr>
 			<td>
 				Link Code:
 			</td>
 			<td>
				<input name="LinkCode" type="text"  id="LinkCode">
 			</td>
 		</tr>

 		<tr>
 			<td>
 				Product ID:
 			</td>
 			<td>
				<input name="ProductID" type="text" id="ProductID">
 			</td>
 		</tr>

 		<tr>
 			<td>
 				Type:
 			</td>
 			<td>
				<input name="Type" type="text" id="Type">
 			</td>
 		</tr>
        <tr>
 			<td>
 				Element:
 			</td>
 			<td>
				<input name="Element" type="text" id="Element">
 			</td>
 		</tr>
 		<tr>
 			<td>
 				Price:
 			</td>
 			<td>
				<input name="Price" type="text" id="Price">
 			</td>
 		</tr>

 		<tr>
 			<td>
 				End Date:
 			</td>
 			<td>
				<input name="EndDate" type="text" id="EndDate">
 			</td>
 		</tr>
		 <tr>
			 <td>
				 Sort ID:
			 </td>
			 <td>
				 <input name="sortid" type="text" id="sortid" value="1">
			 </td>
		 </tr>
 		<tr>
 			<td colspan="2">
 				<input type="submit" name="Save">
 			</td>
 		
 		</tr>
 	</table>

 </form>

</body>
</html>