<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Canada eSchool</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1" />-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 <script src="{{ asset('public/js/jquery-2.2.4.js') }}" type="text/javascript"></script>
   <!-- Bootstrap -->
    <link href="{{ asset('public/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">

    <script src="{{ asset('public/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('public/bootstrap/js/popper.min.js') }}" type="text/javascript"></script>
    <script  src="{{ asset('public/js/underscore-min.js') }}"  type="text/javascript"></script>

    <link rel="stylesheet"  href="{{ asset('public/css/swiper/swiper-bundle.css') }}">
    <script  src="{{ asset('public/js/swiper/swiper-bundle.js') }}"></script>
    <link href="{{ asset('public/adminhtml/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <script src="{{ asset('public/js/vue.js') }}"></script>
    <style>
        /*.div_main_container{*/
        /*margin: auto;*/
        /*width: 80%;*/
        /*}
   16:10  1280x800  1440x900  1680x1050  1920x1200
   16:9  720p(1280x720)  1080p(1920x1080) - 1080p
        /*/
        body{
            background-color: #fff;
            font-family: "Calibri", sans-serif;
            color: #203864;
            font-size: 1.1vw;
        }
        /*500--1440*/
        /*  @media screen and (min-width:500px) {

           }*/
        /*400--1440*/
        @media screen and (min-width: 400px) and (max-width: 1440px) {
            .div_top_page_section{
                width: 100%;
                height: 100px;
                line-height: 100px;
            }
        }
        /*>1440*/
        @media screen and (min-width:1441px) {

            .div_top_page_section{
                width: 100%;
                height: 110px;
                line-height: 110px;
            }
        }
        .div_main_container{
            width: 100%;
            margin-left: 5px;
            margin-right: 15px;
            max-width:1920px;
        }
        .page_max_width{
            max-width:1920px;
        }
        .bg_white{
            color: #203864;
            background-color: #fff;
        }
        .bg_dark_blue{
            color: #fff;
            background-color: #203864;
        }
        .bg_light_gray{
            color: #203864;
            background-color: #bfbfbf;
        }


        .div_top_page_bar{
            width: 100%;
            height: 60px;
            line-height: 60px;
            padding-left: 10px;
            background-color: #203864;
        }
        .div_top_page_bar_space{
            width: 100%;
            height: 10px;
            background-color: #bfbfbf;
        }

        .row_section_space_10{
            width: 100%;
            height: 10px;
        }
        .row_section_space_20{
            width: 100%;
            height: 20px;
        }
        .div_page_navigation{
            width: 100%;
            background-color: #203864;
        }

        #top_bar_buttons_section ul{
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }
        #top_bar_buttons_section li{
            float: left;
            margin-right: 10px;
        }
        #top_bar_buttons_section li a {
            display: block;
            text-align: center;
            text-decoration: none;
        }

        #top_bar_buttons_section li a:hover {

        }
        /*ul*/

        .top_bar_buttons{
            width: 180px;
        }

        /*ul*/
        #top_bar_language_section ul{
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            width: 100%;
            text-align: right;
        }
        #top_bar_language_section li{
            float: right;
            margin-right: 18px;
        }
        #top_bar_language_section li a {
            display: block;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-size: 1.1vw;
        }

        #top_bar_language_section li a:hover {
            color: #203864;
        }
        .page_chat_img{
            width:40px;
        }
        /*ul*/

        .top_main_nav_item{
            color: #fff;
            font-size:1.2vw;
            width: 100%;
            text-align: center;
            border-right: 2px solid #002a5c;

        }
        .top_main_nav_item a:hover {
            background-color: #0050b3;
        }
        .lblmsginput{
            color:red;
        }
    </style>
</head>

<body>
<input type="hidden" id="hdwebsiteurl" value="{{url('/')}}">
   <!--  container-fluid -->
<div class="container-fluid" style="padding: 5px;">
    <!-- Button trigger modal -->
    <!-- Modal -->
    <div class="modal fade" id="modal_appointment" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_first_name" name="tb_first_name" placeholder="First Name *">
                       <label id="lbl_first_name" class="lblmsginput">We’d love to know your name!</label>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_last_name" name="tb_last_name" placeholder="Last Name *">
                        <label id="lbl_last_name" class="lblmsginput">Please enter your last name!</label>
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_email" name="tb_email" placeholder="Email address *">
                        <label id="lbl_email" class="lblmsginput">We need an email we can contact you on!</label>
                        <label id="lbl_email_check" class="lblmsginput">Please enter a valid email!</label>

                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="tb_mobile_number" name="tb_mobile_number" placeholder="Mobile number *">
                        <label id="lbl_mobile_number" class="lblmsginput">Please enter a valid phone number!</label>
                    </div>
                    <div class="form-group">
                        <label>Your preferred study destination *</label>
                        <select id="slt_country" name="slt_country" class="form-control">
                            <option>Canada</option>
                            <option>Australia</option>
                            <option>New Zealand</option>
                            <option>United Kingdom</option>
                            <option>United States</option>
                            <option>Ireland</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Preferred mode of counselling *</label>
                        <select id="slt_counselling" name="slt_counselling" class="form-control">
                            <option value="0">Please select</option>
                            <option value="In-person">In-person</option>
                            <option value="Virtual Counselling">Virtual Counselling</option>
                        </select>
                        <label id="lbl_slt_counselling" class="lblmsginput">Please select your initial counselling!</label>
                    </div>
                    <div class="form-group">
                        Canada eSchool will not share your details with others without your permission:
                        <br>
                        <input id="ck_policy" name="ck_policy" type="checkbox" value="" id="defaultCheck1">
                        I agree to Smart Education Terms, privacy policy and Personal Information Collection Statement (PICS). *
                        <label id="lbl_slt_terms" class="lblmsginput">Please agree to our terms!</label>
                        <br>
                        <input id="ck_phone" name="ck_phone"  type="checkbox" value="" id="defaultCheck1">
                        Please contact me by phone, email or SMS to assist with my enquiry.
                        <br>
                        <input id="ck_info" name="ck_info"  type="checkbox" value="" id="defaultCheck1">
                        I’d love to get useful information from Smart Education about study abroad, scholarships, English Language Development and TOEFL.

                    </div>
                </div>

                <div class="modal-footer">
                    <div class="spinner-border text-primary" id="spinner_pro_image" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                    <div id="result_msg" style="color: #ff1c1c;"></div>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id="btn_appointment_save" class="btn btn-primary">Help me Study Abroad</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <!-- row -->
    <div class="row">
        <div class="col"><!-- col -->
            <div class="div_top_page_bar"><!-- div_top_page_bar -->
                <div style="float: left; width:50%;">
                    <div id="top_bar_buttons_section">
                        <ul>

                            <li>
                                <button type="button" class="btn btn-light top_bar_buttons">Study in Australia</button>
                            </li>
                            <li>
                                <button type="button" class="btn btn-light top_bar_buttons">Study In Japan</button>
                            </li>
                        </ul>
                    </div>
                </div>
                <div style="float: left; width: 30%;">
                   &nbsp;
                </div>
                <div style="float: left;  width: 20%; " id="top_bar_language_section">
                    <ul>
                        <li>
                            <a href="https://canadaeschool.mysmartedu.com/index.php/clg/sc">
                                简体中文
                            </a>

                        <li>

                        <li>
                           <a href="https://canadaeschool.mysmartedu.com/index.php/clg/tc">
                                繁體中文
                            </a>

                        </li>
                        <li>
                          <a href="https://canadaeschool.mysmartedu.com/index.php/clg/en">
                                English
                            </a>

                        </li>
                    </ul>
                </div>
            </div><!-- div_top_page_bar -->
        </div><!-- col -->
    </div>  <!-- row -->

    <div class="row"><!-- row -->
        <div class="col"><!-- col -->
            <div class="div_top_page_bar_space"></div>
        </div><!-- col -->
    </div>  <!-- row -->

     <!-- row -->
    <div class="row">
        <div class="col"><!-- col -->
            <div class="div_top_page_section">
                <div style="float: left; width: 30%;">
                &nbsp;
                </div>
                <div style="float: left; width: 40%;">
                <img src="{{asset('/public/images/Canada eSchool transparent logo.jpg')}}"  style="width: 100%;">
                </div>
                <div  style="float: left; width: 30%;height: 100px; color: white; text-align: right;">
                    <div style="height: 40px; line-height: 40px;">
                        <a href="http://jpt.mysmartedu.com/index.php/edujptadmin/" style="text-decoration: none;">
                            <img src="{{asset('/public/images/chat/wechat_v1.png')}}" class="page_chat_img">
                        </a>

                          <a href="#">
                            <img src="{{asset('/public/images/chat/Youtube.png')}}" class="page_chat_img">
                        </a>
                         <a href="#">
                            <img src="{{asset('/public/images/chat/facebook.png')}}" class="page_chat_img">
                        </a>

                    </div>
                    <div style="height: 60px;line-height: 60px; padding-right: 5px; ">
                         <button type="button" class="btn btn-danger" style="width: 50%;" id="btn_appointment" ><span style="font-size: 1.3vw;">Book An Appointment</span></button>
                    </div>
                </div>
            </div><!-- div_top_page_section -->
        </div><!-- col -->
    </div>  <!-- row -->

     <!-- row -->
    <div class="row">
        <div class="col"><!-- col -->
            <!-- div_page_navigation -->
          <div class="div_page_navigation">
              <nav class="navbar navbar-expand-md navbar-custom navbar-dark" style="z-index:2;padding: 0px;">
                  <div class="collapse navbar-collapse" id="collapsibleNavbar" style="width: 100%; padding-top: 10px; padding-bottom: 10px;" >
                      <ul class="navbar-nav" style="width: 100%;  ">
                      @foreach ($page_data['main_menus'] as $main_menu)
                          @if ($main_menu->has_sub_menus === 0)
                                  <li class="nav-item top_main_nav_item">
                                      <a class="nav-link" v-bind:style="{ color: activeColor}" href="{{$main_menu->url}}">
                                          {{$main_menu->menu_name}}
                                      </a>
                                  </li>
                          @else
                                  <li class="nav-item dropdown top_main_nav_item">
                                      <a class="nav-link dropdown-toggle"  v-bind:style="{ color: activeColor}" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                          {{$main_menu->menu_name}}
                                      </a>
                                      <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #fff;">
                                          @foreach ($main_menu->submenus as $submenu)
                                              <a class="dropdown-item" style="color: #203864;background-color: #fff;font-size:1.2vw" href="{{$submenu->url}}">{{$submenu->menu_name}}</a>
                                              <div class="dropdown-divider"></div>
                                          @endforeach
                                      </div>
                                  </li>
                          @endif
                      @endforeach
                      </ul>
                  </div>
              </nav>
          </div> <!-- div_page_navigation -->
        </div><!-- col -->
    </div>  <!-- row -->


</div> <!--  container-fluid -->

    <script type="text/javascript" src="{{ asset('public/js/pages/page_header.js') }}"></script>
   <script type="text/javascript">
       $( document ).ready(function() {
           $("#lbl_first_name").hide();
           $("#lbl_last_name").hide();
           $("#lbl_email").hide();
           $("#lbl_mobile_number").hide();
           $("#lbl_slt_counselling").hide();
           $("#lbl_slt_terms").hide();
           $("#lbl_email_check").hide();

           $( "#btn_appointment" ).click(function() {
               $('#modal_appointment').modal('toggle');
           });





               $.ajaxSetup({
                   headers: {
                       'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                   }
               });
//----------------------------------------------------------------
               $('#btn_appointment_save').click(function () {
                   $("#lbl_first_name").hide();
                   $("#lbl_last_name").hide();
                   $("#lbl_email").hide();
                   $("#lbl_mobile_number").hide();
                   $("#lbl_slt_counselling").hide();
                   $("#lbl_slt_terms").hide();
                   $("#lbl_email_check").hide();


                   var weburl=$("#hdwebsiteurl").val();

                   var tb_first_name = $("#tb_first_name").val();
                   var tb_last_name = $("#tb_last_name").val();
                   var tb_email = $("#tb_email").val();
                   var tb_mobile_number = $("#tb_mobile_number").val();
                   var slt_country = $("#slt_country").val();
                   var slt_counselling = $("#slt_counselling").val();
                   var ck_policy=$('#ck_policy').is(":checked");
                   var ck_phone=$('#ck_phone').is(":checked");
                   var ck_info=$('#ck_info').is(":checked");

                   //-------------------------------------------------------------------
                   if(tb_first_name==""){
                       $("#lbl_first_name").show();
                       return false;
                   }

                   if(tb_last_name==""){
                       $("#lbl_last_name").show();
                       return false;
                   }

                   if(tb_email==""){
                       $("#lbl_email").show();
                       return false;
                   }
                   else{
                       if(isEmail(tb_email)==false){
                           $("#lbl_email_check").show();
                           return false;
                       }
                   }
                   if(tb_mobile_number==""){
                       $("#lbl_mobile_number").show();
                       return false;
                   }
                   if(slt_counselling=="0"){
                       $("#lbl_slt_counselling").show();
                       return false;
                   }
                   if(ck_policy==false){
                       $("#lbl_slt_terms").show();
                       return false;
                   }
                   var postdata={
                       first_name:tb_first_name
                       ,last_name:tb_last_name
                       ,email:tb_email
                       ,mobile_number:tb_mobile_number
                       ,country:slt_country
                       ,counselling:slt_counselling
                       ,policy:ck_policy
                       ,phone:ck_phone
                       ,info:ck_info
                   };

                   //ajax------------------------------------------
                   $.ajax({
                       url: weburl+"/index.php/client_reg",
                       type: 'post',
                       data:postdata,
                       dataType: 'json',
                       beforeSend: function() {
                           $('#spinner_pro_image').show();
                           $('#btnlogin').prop( "disabled", true );
                       },
                       complete: function() {
                           $('#spinner_pro_image').hide();
                           $('#btnlogin').prop( "disabled", false );
                       },
                       success: function(data) {
                           //console.log(data);
                           if(data){
                               $("#result_msg").html("Your data has been saved, we will contact you.");
                           }
                           else{
                               $("#result_msg").html("Your data has been saved unsuccessfully.");
                           }


                       },
                       error: function(xhr, ajaxOptions, thrownError) {
                           alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                       }
                   });
                   //ajax------------------------------------------

               });

           function isEmail(email) {
               var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
               return regex.test(email);
           }
       });
   </script>
</body>

</html>