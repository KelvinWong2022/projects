Validation Logic

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{url('/myvalidate_post/')}}" method="post">
    <input type="hidden" name="_token" value="{{ csrf_token() }}">
    <input type="text" name="title">
    @error('title')
    <div class="alert alert-danger">{{ $message }}</div>
@enderror
    <button class="btn-style-one" type="submit" data-loading-text="Please wait...">Submit</button>
</form>