@include('header')
<style>
    .page_top_bar_section {

        background-color: #666;
        height:120px; /* You must set a specified height */
        background-position: center; /* Center the image */
        background-repeat: no-repeat; /* Do not repeat the image */
        background-size: cover; /* Resize the background image to cover the entire container */
    }
    .page_top_bar_section_title{
        float:left; width: 80%;
        color: #fff;
        font-size: 3rem;
        font-weight: 800;
    }

</style>
<!--Page top bar-->
<div class="row page_top_bar_section" id="page_top_bar_section_id">
    <div id="text_top_image" v-bind:class="{container_content:isActive}">
        <span>{{Str::upper($page_data['page_article']->title_en)}}</span>
    </div>

</div>

<script>
    var vue_top_bar_obj=new Vue({
        el:'#page_top_bar_section_id',
        data:{
            isActive:true
        }
    })
    setTopbarHeight();
    $( window ).resize(function() {
        setTopbarHeight();
    });
    function setTopbarHeight() {
        if($(window).width()>700){
            var page_top_bar_w=$('#page_top_bar_section_id').width();
            var page_top_bar_h=page_top_bar_w/5;
            $('#page_top_bar_section_id').height(page_top_bar_h);
            $('#text_top_image').height(page_top_bar_h);
            var text_margin=(page_top_bar_h-$('#page_top_bar_section_title').height())/2;
            $('#text_top_image').css('padding-top',text_margin);
            //$('#text_top_image').css('padding-left',30);
            // vue_top_bar_obj.isActive=false;
            // vue_top_bar_obj.isActive=true;
            //$("#text_top_image" ).toggleClass("container_content","container_content_2" );
            // $('#text_top_image').removeClass('container_content');
            // $( "#text_top_image" ).addClass("container_content");
        }
        else
        {
            var page_top_bar_w=$('#page_top_bar_section_id').width();
            var page_top_bar_h=page_top_bar_w/5+30;
            $('#page_top_bar_section_id').height(page_top_bar_h);
            $('#text_top_image').height(page_top_bar_h);
            var text_margin=(page_top_bar_h-$('#page_top_bar_section_title').height())/2;
            $('#text_top_image').css('padding-top',text_margin);
            //$('#text_top_image').css('padding-left',30);
            // vue_top_bar_obj.isActive=false;
            // vue_top_bar_obj.isActive=true;
            //$("#text_top_image" ).toggleClass("container_content","container_content_2" );
            // $('#text_top_image').removeClass('container_content');
            // $( "#text_top_image" ).addClass("container_content");
        }
    }

    $('#page_top_bar_section_id').css('background-image', 'url(/public/images/{{$page_data['page_article']->img}})');
</script>
<!--Page top bar-->
<!--Page top bar-->
<!-- Contact Page -->
<div class="contact-page" style="margin-top: 30px;">
    <div class="container">
        <div class="section-title text-center">
            <div class="section_title_text">{{$page_data['appointment_text']['btn_appointment']}}</div>
            <h2></h2>
        </div>
        <!--Finance Section-->
        <section class="finance-section" style="padding: 1px;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-xs-12">
                        <div class="image-box">
                            <figure>
                                <img src="/uploadimages/images/contact-us_1200.jpg" alt="">
                            </figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-xs-12">
                        <form action="{{url('/appointment/')}}" method="post">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <div class="form-group">
                            <input type="text" class="form-control" id="tb_first_name" name="tb_first_name" placeholder="{{$page_data['appointment_text']['first_name']}}" required="">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="tb_last_name" name="tb_last_name" placeholder="{{$page_data['appointment_text']['last_name']}}" required="">
                        </div>
                        <div class="form-group">
                            <input type="email" id="tb_email" name="tb_email"  class="form-control" value="" placeholder="{{$page_data['appointment_text']['email']}}" required="">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="tb_mobile_number" name="tb_mobile_number" placeholder="{{$page_data['appointment_text']['mobile']}}" required="">
                        </div>
                        <div class="form-group">
                            <select id="slt_country" name="slt_country" class="form-control" required="required">
                                <option value="">{{$page_data['appointment_text']['destination']}}</option>
                                <option>{{$page_data['appointment_text']['country_1']}}</option>
                                <option>{{$page_data['appointment_text']['country_2']}}</option>
                                <option>{{$page_data['appointment_text']['country_3']}}</option>
                                <option>{{$page_data['appointment_text']['country_4']}}</option>
                                <option>{{$page_data['appointment_text']['country_5']}}</option>
                                <option>{{$page_data['appointment_text']['country_6']}}</option>
                            </select>
                        </div>

                        <div class="form-group"   >


                            <select id="slt_counselling" name="slt_counselling" class="form-control" required="required">
                                <option value="">{{$page_data['appointment_text']['counselling']}}</option>
                                <option value="{{$page_data['appointment_text']['counselling_1']}}">{{$page_data['appointment_text']['counselling_1']}}</option>
                                <option value="{{$page_data['appointment_text']['counselling_2']}}">{{$page_data['appointment_text']['counselling_2']}}</option>
                            </select>
                        </div>

                        <b>{{$page_data['appointment_text']['permission']}}</b>

                            <br>
                            &nbsp;<input id="ck_policy" name="ck_policy" type="checkbox"  required="">{{$page_data['appointment_text']['policy']}}
                            <br>
                            &nbsp;<input id="ck_phone" name="ck_phone"  type="checkbox"> &nbsp;{{$page_data['appointment_text']['phonesms']}}
                            <br>
                            &nbsp;<input id="ck_info" name="ck_info"  type="checkbox"> &nbsp;{{$page_data['appointment_text']['information']}}

                            @if ($page_data['appointment_msg']=== "yes")
                            <div style="width: 100%; background-color:#0073e6; color: #fff; text-align: center; border-radius: 5px; padding: 5px;">
                                You have successfully made an appointment, we will contact you soon.<br>
                                你已經成功預約，我們即將與你聯絡。
                            </div>
                            @endif
                        <div class="form-group form-bottom">
                            <br>
                            <button class="btn-style-one" type="submit" data-loading-text="Please wait...">{{$page_data['appointment_text']['submit']}}</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </section><!--End Finance Section-->
    </div>
</div>
<!-- End Contact Page -->
{!! $page_data['page_article']->content !!}
@include('footer')