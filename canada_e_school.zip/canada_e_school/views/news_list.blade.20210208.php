@include('header')
<style>
    .page_top_bar_section {
        background-image: url("/public/images/canada-e-school-small-banner.jpg"); /* The image used */
        background-color: #666;
        height:120px; /* You must set a specified height */
        background-position: center; /* Center the image */
        background-repeat: no-repeat; /* Do not repeat the image */
        background-size: cover; /* Resize the background image to cover the entire container */
    }
    .page_top_bar_section_title{
        float:left; width: 80%;
        color: #fff;
        font-size: 3rem;
        font-weight: 800;
    }
</style>
<!--Page top bar-->
<div class="row page_top_bar_section" id="page_top_bar_section_id">
    <div style="width: 100%">
        <div style="float:left; width: 10%">&nbsp;</div>
        <div class="page_top_bar_section_title">{{Str::upper($page_data['page_article']->title_en)}}</div>
        <div style="float:left; width: 10%">&nbsp;</div>
    </div>
</div>
<script>
    setTopbarHeight();
    $( window ).resize(function() {
        setTopbarHeight();
    });
    function setTopbarHeight() {
        var page_top_bar_w=$('#page_top_bar_section_id').width();
        var page_top_bar_h=page_top_bar_w/5;
        $('#page_top_bar_section_id').height(page_top_bar_h);
        var text_margin=(page_top_bar_h-$('.page_top_bar_section_title').height())/2;
        $('.page_top_bar_section_title').css('margin-top',text_margin);

    }
</script>
<!--Page top bar-->
<!--Page top bar-->

@include('footer')