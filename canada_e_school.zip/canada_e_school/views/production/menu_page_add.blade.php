<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{$page_data['admin_name']}}</title>
    <script src="{{ asset('public/adminhtml/vendors/jquery/dist/jquery.min.js') }}"></script>
    <link href="{{ asset('public/adminhtml/vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{ asset('public/adminhtml/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{ asset('public/adminhtml/vendors/nprogress/nprogress.css') }}" rel="stylesheet">
    <!-- iCheck -->
    <link href="{{ asset('public/adminhtml/vendors/iCheck/skins/flat/green.css') }}" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->

    <!-- Select2 -->
    <link href="{{ asset('public/adminhtml/vendors/select2/dist/css/select2.min.css') }}" rel="stylesheet">
    <!-- Switchery -->
    <link href="{{ asset('public/adminhtml/vendors/switchery/dist/switchery.min.css') }}" rel="stylesheet">
    <!-- starrr -->
    <link href="{{ asset('public/adminhtml/vendors/starrr/dist/starrr.css') }}" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="{{ asset('public/adminhtml/vendors/bootstrap-daterangepicker/daterangepicker.css') }}" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="{{ asset('public/adminhtml/build/css/custom.min.css') }}" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('public/js/jquery-ui-1.12.0/jquery-ui.css') }}">
    <script src="{{ asset('public/js/jquery-ui-1.12.0/jquery-ui.js') }}"></script>
    <script src="{{ asset('public/ckeditor/ckeditor.js') }}"></script>
    <script src="{{ asset('public/ckfinder/ckfinder.js') }}"></script>

    <script>
        $( function() {
            $( "#tabs_title" ).tabs();
        } );
        $( function() {
            $( "#tabs_text" ).tabs();
        } );
    </script>
    <style>
        .page_btn_back{
            width: 120px;
            height: 38px;
            background-color: blue;
            color: white;
            border-radius: 5px;
        }
    </style>
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="#" class="site_title"><span>{{$page_data['admin_name']}}</span></a>
                </div>

                <div class="clearfix"></div>
                <br />

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">

                        <ul class="nav side-menu">
                            {!! $page_data['page_menus'] !!}
                        </ul>
                    </div>

                </div>
                <!-- /sidebar menu -->

                <!-- /menu footer buttons -->
                <div class="sidebar-footer hidden-small">
                    <a data-toggle="tooltip" data-placement="top" title="Settings">
                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                        <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Lock">
                        <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                    </a>
                </div>
                <!-- /menu footer buttons -->
            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <div class="nav toggle">
                    <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                </div>
                <nav class="nav navbar-nav">

                </nav>
            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">

                <div class="row">
                    <div class="col-md-12 col-sm-12 ">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Detail</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <form action="{{url('/menu_add_save/')}}" method="post" class="form-horizontal form-label-left"   onsubmit="return validateForm()" enctype="multipart/form-data">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <input type="hidden" name="articleid" id="articleid" >
                                    <input type="hidden" name="category" id="category" value="{{$page_data['category']}}" >
                                    <input type="hidden" name="hd_image" id="hd_image">

                                    <div class="form-group" style="color: red;font-size: 20px;">

                                        {{$page_data['msg']}}
                                    </div>
                                    <div id="tabs_title">
                                        <ul>
                                            <li><a href="#tabs-1">English</a></li>
                                            <li><a href="#tabs-2">繁體</a></li>
                                            <li><a href="#tabs-3">简体</a></li>
                                        </ul>
                                        <div id="tabs-1">
                                            <div class="form-group">
                                                <label for="title_en">title</label>
                                                <input name="title_en" type="text" class="form-control" id="title_en">
                                            </div>
                                        </div>
                                        <div id="tabs-2">
                                            <label for="title_tc">標題</label>
                                            <input name="title_tc" type="text" class="form-control" id="title_tc">
                                        </div>
                                        <div id="tabs-3">
                                            <label for="title_sc">标题</label>
                                            <input name="title_sc" type="text" class="form-control" id="title_sc">
                                        </div>
                                    </div>
                                    <!--title-->

                                    <div class="form-group">
                                        <label for="sortid">image</label>
                                        <input type="file" id="upload_img_file" name="image" class="form-control">
                                    </div>

                                    <div id="tabs_text">
                                        <ul>
                                            <li><a href="#tabs-1">English</a></li>
                                            <li><a href="#tabs-2">繁體</a></li>
                                            <li><a href="#tabs-3">简体</a></li>
                                        </ul>
                                        <div id="tabs-1">
                                            <div class="form-group">
                                                <label for="text_en">Content</label>
                                                <textarea class="form-control" id="text_en" name="text_en" rows="10"></textarea>
                                            </div>
                                        </div>
                                        <div id="tabs-2">
                                            <div class="form-group">
                                                <label for="text_tc">內容</label>
                                                <textarea class="form-control" id="text_tc" name="text_tc" rows="10"></textarea>
                                            </div>
                                        </div>
                                        <div id="tabs-3">
                                            <div class="form-group">
                                                <label for="text_sc">内容</label>
                                                <textarea class="form-control" id="text_sc" name="text_sc" rows="10"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <script type="text/javascript">

                                        CKEDITOR.replace('text_en', {
                                            allowedContent:true,
                                            filebrowserBrowseUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/ckfinder.html',
                                            filebrowserImageBrowseUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/ckfinder.html?Type=Images',
                                            filebrowserUploadUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                            filebrowserImageUploadUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images'
                                        } );
                                        //CKEDITOR.replace( 'text_en', {
                                        //    filebrowserBrowseUrl: '/new/ckfinder/new/ckfinder.html',
                                        //    filebrowserImageBrowseUrl: '/new/ckfinder/new/ckfinder.html?Type=Images',
                                        //    filebrowserUploadUrl: '/new/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                        //    filebrowserImageUploadUrl: '/new/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
                                        //    filebrowserWindowWidth : '1000',
                                        //    filebrowserWindowHeight : '700'
                                        //});
                                        CKEDITOR.replace('text_tc', {
                                            allowedContent:true,
                                            filebrowserBrowseUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/ckfinder.html',
                                            filebrowserImageBrowseUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/ckfinder.html?Type=Images',
                                            filebrowserUploadUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                            filebrowserImageUploadUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images'
                                        } );

                                        CKEDITOR.replace('text_sc', {
                                            allowedContent:true,
                                            filebrowserBrowseUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/ckfinder.html',
                                            filebrowserImageBrowseUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/ckfinder.html?Type=Images',
                                            filebrowserUploadUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                            filebrowserImageUploadUrl: 'https://canadaeschool.mysmartedu.com/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images'
                                        } );
                                        //CKEDITOR.replace( 'text_tc' );
                                        //CKEDITOR.replace( 'text_sc' );
                                    </script>
                                    <!--text-->
                                    <div class="form-group">
                                        <label for="sortid">Sort Number</label>
                                        <input name="sortid"  type="text" class="form-control" id="sortid">
                                    </div>
                                    <a href="{{url('/menu_list/')}}/{{$page_data['category']}}" style="font-size: 20px;">
                                        <input type="button" class="page_btn_back" value="<<back">
                                    </a>
                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                    <button type="submit" class="btn btn-success" style="width: 200px;">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
            <div class="pull-right">
                Copyright © 2020 Smart Education . All Right Reserved.
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div>
</div>

<!-- jQuery -->

<!-- Bootstrap -->
<script src="{{ asset('public/adminhtml/vendors/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
<!-- FastClick -->
<script src="{{ asset('public/adminhtml/vendors/fastclick/lib/fastclick.js') }}"></script>
<!-- NProgress -->
<script src="{{ asset('public/adminhtml/vendors/nprogress/nprogress.js') }}"></script>
<!-- bootstrap-progressbar -->
<script src="{{ asset('public/adminhtml/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js') }}"></script>
<!-- iCheck -->
<script src="{{ asset('public/adminhtml/vendors/iCheck/icheck.min.js') }}"></script>
<!-- bootstrap-daterangepicker -->
<script src="{{ asset('public/adminhtml/vendors/moment/min/moment.min.js') }}"></script>
<script src="{{ asset('public/adminhtml/vendors/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
<!-- bootstrap-wysiwyg -->
<script src="{{ asset('public/adminhtml/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js') }}"></script>
<script src="{{ asset('public/adminhtml/vendors/jquery.hotkeys/jquery.hotkeys.js') }}"></script>
<script src="{{ asset('public/adminhtml/vendors/google-code-prettify/src/prettify.js') }}"></script>
<!-- jQuery Tags Input -->
<script src="{{ asset('public/adminhtml/vendors/jquery.tagsinput/src/jquery.tagsinput.js') }}"></script>
<!-- Switchery -->
<script src="{{ asset('public/adminhtml/vendors/switchery/dist/switchery.min.js') }}"></script>
<!-- Select2 -->
<script src="{{ asset('public/adminhtml/vendors/select2/dist/js/select2.full.min.js') }}"></script>
<!-- Parsley -->
<script src="{{ asset('public/adminhtml/vendors/parsleyjs/dist/parsley.min.js') }}"></script>
<!-- Autosize -->
<script src="{{ asset('public/adminhtml/vendors/autosize/dist/autosize.min.js') }}"></script>
<!-- jQuery autocomplete -->
<script src="{{ asset('public/adminhtml/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js') }}"></script>
<!-- starrr -->
<script src="{{ asset('public/adminhtml/vendors/starrr/dist/starrr.js') }}"></script>
<!-- Custom Theme Scripts -->
<script src="{{ asset('public/adminhtml/build/js/custom.min.js') }}"></script>
<script>
    function validateForm() {
        if($('#title_en').val()=="" ||$('#title_tc').val()=="" ||$('#title_sc').val()=="" ){
            alert("Please input English & Chinese titles.");
            $('#title_en').focus();
            return false;
        }

        if($('#text_en').val()==""||$('#text_tc').val()==""||$('#text_sc').val()==""){
            alert("Please input English & Chinese content.");
            $('#text_en').focus();
            return false;
        }
        if($('#sortid').val()==""){
            alert("Please input sort number.");
            $('#sortid').focus();
            return false;
        }
    }
</script>
</body></html>
