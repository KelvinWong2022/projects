<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>My Smart Education </title>
    <script src="<?php echo base_url();?>adminhtml/vendors/jquery/dist/jquery.min.js"></script>
    <link href="<?php echo base_url();?>adminhtml/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url();?>adminhtml/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url();?>adminhtml/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo base_url();?>adminhtml/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="<?php echo base_url();?>adminhtml/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="<?php echo base_url();?>adminhtml/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="<?php echo base_url();?>adminhtml/vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="<?php echo base_url();?>adminhtml/vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="<?php echo base_url();?>adminhtml/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url();?>adminhtml/build/css/custom.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url(); ?>js/jquery-ui-1.12.0/jquery-ui.css">
    <script src="<?php echo base_url(); ?>js/jquery-ui-1.12.0/jquery-ui.js"></script>
    <script src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <script src="<?php echo base_url(); ?>ckfinder/new/ckfinder.js"></script>

    <script>
        $( function() {
            $( "#tabs_title" ).tabs();
        } );
        $( function() {
            $( "#tabs_text" ).tabs();
        } );
    </script>
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="#" class="site_title"><span><?php echo  $this->config->item('backend_title');?></span></a>
                </div>

                <div class="clearfix"></div>


                <br />

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">

                        <ul class="nav side-menu">

                            <?php echo $left_menu; ?>
                        </ul>
                    </div>

                </div>
                <!-- /sidebar menu -->

                <!-- /menu footer buttons -->
                <div class="sidebar-footer hidden-small">
                    <a data-toggle="tooltip" data-placement="top" title="Settings">
                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                        <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Lock">
                        <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo base_url(); ?>smarteduadmin/login_out">
                        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                    </a>
                </div>
                <!-- /menu footer buttons -->
            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <div class="nav toggle">
                    <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                </div>

            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">&nbsp;

                <div class="row">
                    <div class="col-md-12 col-sm-12 ">
                        <div class="x_panel">

                            <div class="x_content">
                                <br />
                                <form action="<?php echo base_url(); ?>index.php/admin/arcitle_mod_save/<?php echo $article['id']; ?>" method="post" data-parsley-validate class="form-horizontal form-label-left"  enctype="multipart/form-data">
                                    <div class="form-group">
                                        <?php if($msg !=""){?>
                                            <div class="alert alert-warning" role="alert">
                                                <span style="font-size: 16px; color: black;"><?php echo $msg;?></span>
                                            </div>
                                        <?php } ?>
                                        <input name="articleid" type="text" class="form-control" id="articleid" value="<?php echo($article['id']); ?> " readonly="readonly"/>
                                    </div>
                                    <!--title-->
                                    <div id="tabs_title">
                                        <ul>
                                            <li><a href="#tabs-1">English</a></li>
                                            <li><a href="#tabs-2">繁體</a></li>
                                            <li><a href="#tabs-3">简体</a></li>
                                        </ul>
                                        <div id="tabs-1">
                                            <div class="form-group">
                                                <label for="title_en">Title</label>
                                                <input name="title_en" type="text" class="form-control" id="title_en" value="<?php echo($article['title_en']); ?> ">
                                            </div>
                                        </div>
                                        <div id="tabs-2">
                                            <label for="title_tc">標題</label>
                                            <input name="title_tc" type="text" class="form-control" id="title_tc"  value="<?php echo($article['title_tc']); ?> ">
                                        </div>
                                        <div id="tabs-3">
                                            <label for="title_sc">标题</label>
                                            <input name="title_sc" type="text" class="form-control" id="title_sc" value="<?php echo($article['title_sc']); ?> ">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <br>
                                        <label for="sortid">Image</label>
                                        <input type="hidden" name="hdimagename" value="<?php echo($article['media']); ?>">
                                        <input type="file" name="newsimg" id="newsimg" size="20" />

                                        <?php
                                        echo '<img src="'.$article['media'].'" style="height:150px;">';
//                                        if($category==1103){//Photo Gallery
//                                            echo '<img src="'.base_url().'uploadimages/'.$article['media'].'" style="height:150px;">';
//                                        }
//                                        else{
//                                            echo '<img src="'.base_url().'uploadimages/'.$article['media'].'" style="height: 100px;">';
//                                        }
                                        ?>
                                        <span style="color:red;">Recommended image size:400 x 300 (px)</span>
                                    </div>
                                    <!--title-->
                                    <!--category-->
                                    <!--<div class="form-group" style="margin-left:20px;">
                                       <label for="category">Category</label>
                                       <select class="form-control" id="category" name="category">
                                         <option value="toeic">TOEIC</option>
                                           <option value="toeicsw">TOEIC SW</option>

                                       </select>
                                     </div>-->
                                    <!--category-->
                                    <!--text-->
                                    <div id="tabs_text">
                                        <ul>
                                            <li><a href="#tabs-1">English</a></li>
                                            <li><a href="#tabs-2">繁體</a></li>
                                            <li><a href="#tabs-3">简体</a></li>
                                        </ul>
                                        <div id="tabs-1">
                                            <div class="form-group">
                                                <label for="text_en">Content</label>
                                                <textarea class="form-control" id="text_en" name="text_en" rows="10"><?php echo($article['content_en']); ?></textarea>
                                            </div>
                                        </div>
                                        <div id="tabs-2">
                                            <div class="form-group">
                                                <label for="text_tc">內容</label>
                                                <textarea class="form-control" id="text_tc" name="text_tc" rows="10"><?php echo($article['content_tc']); ?></textarea>
                                            </div>
                                        </div>
                                        <div id="tabs-3">
                                            <div class="form-group">
                                                <label for="text_sc">内容</label>
                                                <textarea class="form-control" id="text_sc" name="text_sc" rows="10"><?php echo($article['content_sc']); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <script type="text/javascript">

                                        CKEDITOR.replace('text_en', {
                                            allowedContent:true,
                                            filebrowserBrowseUrl: '/ckfinder/ckfinder.html',
                                            filebrowserImageBrowseUrl: '/ckfinder/ckfinder.html?Type=Images',
                                            filebrowserUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                            filebrowserImageUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images'
                                        } );
                                        //CKEDITOR.replace( 'text_en', {
                                        //    filebrowserBrowseUrl: '/new/ckfinder/new/ckfinder.html',
                                        //    filebrowserImageBrowseUrl: '/new/ckfinder/new/ckfinder.html?Type=Images',
                                        //    filebrowserUploadUrl: '/new/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                        //    filebrowserImageUploadUrl: '/new/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
                                        //    filebrowserWindowWidth : '1000',
                                        //    filebrowserWindowHeight : '700'
                                        //});
                                        CKEDITOR.replace('text_tc', {
                                            allowedContent:true,
                                            filebrowserBrowseUrl: '/ckfinder/ckfinder.html',
                                            filebrowserImageBrowseUrl: '/ckfinder/ckfinder.html?Type=Images',
                                            filebrowserUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                            filebrowserImageUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images'
                                        } );

                                        CKEDITOR.replace('text_sc', {
                                            allowedContent:true,
                                            filebrowserBrowseUrl: '/ckfinder/ckfinder.html',
                                            filebrowserImageBrowseUrl: '/ckfinder/ckfinder.html?Type=Images',
                                            filebrowserUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                                            filebrowserImageUploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images'
                                        } );
                                        //CKEDITOR.replace( 'text_tc' );
                                        //CKEDITOR.replace( 'text_sc' );
                                    </script>
                                    <!--text-->
                                    <div class="form-group">
                                        <label for="sortid">Sort Number</label>
                                        <input name="sortid"  type="text" class="form-control" id="sortid" value="<?php echo($article['sortid']); ?> ">
                                    </div>
                                    <a href="<?php echo base_url(); ?>index.php/admin/articles_list/<?php echo $category; ?>" style="font-size: 20px;">
                                        Back to Pages List
                                    </a>
                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                    <button type="submit" class="btn btn-success">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
            <div class="pull-right">
                Copyright © 2020 Smart Education . All Right Reserved.
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div>
</div>

<!-- jQuery -->

<!-- Bootstrap -->
<script src="<?php echo base_url();?>adminhtml/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url();?>adminhtml/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?php echo base_url();?>adminhtml/vendors/nprogress/nprogress.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo base_url();?>adminhtml/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url();?>adminhtml/vendors/iCheck/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url();?>adminhtml/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url();?>adminhtml/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-wysiwyg -->
<script src="<?php echo base_url();?>adminhtml/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
<script src="<?php echo base_url();?>adminhtml/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
<script src="<?php echo base_url();?>adminhtml/vendors/google-code-prettify/src/prettify.js"></script>
<!-- jQuery Tags Input -->
<script src="<?php echo base_url();?>adminhtml/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
<!-- Switchery -->
<script src="<?php echo base_url();?>adminhtml/vendors/switchery/dist/switchery.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url();?>adminhtml/vendors/select2/dist/js/select2.full.min.js"></script>
<!-- Parsley -->
<script src="<?php echo base_url();?>adminhtml/vendors/parsleyjs/dist/parsley.min.js"></script>
<!-- Autosize -->
<script src="<?php echo base_url();?>adminhtml/vendors/autosize/dist/autosize.min.js"></script>
<!-- jQuery autocomplete -->
<script src="<?php echo base_url();?>adminhtml/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
<!-- starrr -->
<script src="<?php echo base_url();?>adminhtml/vendors/starrr/dist/starrr.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo base_url();?>adminhtml/build/js/custom.min.js"></script>

</body></html>
