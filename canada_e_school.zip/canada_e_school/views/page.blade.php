@include('header')
<style>
    .page_top_bar_section {
        /*background-image: url("/public/images/canada-e-school-small-banner.jpg");  The image used */

        background-position: center; /* Center the image */
        background-repeat: no-repeat; /* Do not repeat the image */
        background-size: cover; /* Resize the background image to cover the entire container */
    }
    #page_top_bar_section_title{


    }


</style>
<!--Page top bar-->
<div class="row page_top_bar_section" id="page_top_bar_section_id">
    <div id="text_top_image" v-bind:class="{container_content:isActive}">
        <span>{{Str::upper($page_data['page_article']->title)}}</span>
    </div>

    {{--<div style="width: 100%">--}}
        {{--<div style="float:left; width: 10%">&nbsp;</div>--}}
        {{--<div class="page_top_bar_section_title">{{Str::upper($page_data['page_article']->title_en)}}</div>--}}
        {{--<div style="float:left; width: 10%">&nbsp;</div>--}}
    {{--</div>--}}
</div>

<script>
    var vue_top_bar_obj=new Vue({
        el:'#page_top_bar_section_id',
        data:{
            isActive:true
        }
    })
    setTopbarHeight();
    $( window ).resize(function() {
        setTopbarHeight();
    });
    function setTopbarHeight() {
        if($(window).width()>700){
            var page_top_bar_w=$('#page_top_bar_section_id').width();
            var page_top_bar_h=page_top_bar_w/5;
            $('#page_top_bar_section_id').height(page_top_bar_h);
            $('#text_top_image').height(page_top_bar_h);
            var text_margin=(page_top_bar_h-$('#page_top_bar_section_title').height())/2;
            $('#text_top_image').css('padding-top',text_margin);
            //$('#text_top_image').css('padding-left',30);
            // vue_top_bar_obj.isActive=false;
            // vue_top_bar_obj.isActive=true;
            //$("#text_top_image" ).toggleClass("container_content","container_content_2" );
            // $('#text_top_image').removeClass('container_content');
            // $( "#text_top_image" ).addClass("container_content");
        }
        else
        {
            var page_top_bar_w=$('#page_top_bar_section_id').width();
            var page_top_bar_h=page_top_bar_w/5+30;
            $('#page_top_bar_section_id').height(page_top_bar_h);
            $('#text_top_image').height(page_top_bar_h);
            var text_margin=(page_top_bar_h-$('#page_top_bar_section_title').height())/2;
            $('#text_top_image').css('padding-top',text_margin);
            //$('#text_top_image').css('padding-left',30);
            // vue_top_bar_obj.isActive=false;
            // vue_top_bar_obj.isActive=true;
            //$("#text_top_image" ).toggleClass("container_content","container_content_2" );
            // $('#text_top_image').removeClass('container_content');
            // $( "#text_top_image" ).addClass("container_content");
        }

    }

    $('#page_top_bar_section_id').css('background-image', 'url(/public/images/{{$page_data['page_article']->img}})');
</script>
<!--Page top bar-->
<!--Page top bar-->
{!! $page_data['page_article']->content !!}
@include('footer')