<?php
//file : app/config/constants.php

return [
	'ADMIN_NAME' => 'Canada eSchool'
];