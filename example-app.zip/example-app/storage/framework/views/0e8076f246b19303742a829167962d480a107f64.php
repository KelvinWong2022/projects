<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $page_data['page_tile']; ?></title>

      
    </head>
    <body class="antialiased">
       <?php echo $page_data['page_tile']; ?>

    </body>
</html>
<?php /**PATH D:\xampp\htdocs\example-app\resources\views/index.blade.php ENDPATH**/ ?>