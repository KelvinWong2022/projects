<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;

class IndexController extends Controller
{
    public function __construct()
    {
        
    }
    
    public function index()
    {
        $data['page_tile']="Home page";
        return view('index')->with('page_data',$data);
    }

     public function page()
    {
        $data['page_tile']="Test page";
        return view('index')->with('page_data',$data);
    }

      public function contact()
    {
        $data['page_tile']="Contact page";
        return view('contact')->with('page_data',$data);
    }
}
